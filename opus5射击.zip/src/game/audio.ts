// Fully procedural WebAudio sound design - no assets required.

class AudioEngine {
  ctx: AudioContext | null = null;
  master: GainNode | null = null;
  sfxBus: GainNode | null = null;
  musicBus: GainNode | null = null;
  noiseBuf: AudioBuffer | null = null;
  muted = false;
  private musicTimer: number | null = null;
  private step = 0;

  init() {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') void this.ctx.resume();
      return;
    }
    const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new Ctx();
    this.ctx = ctx;
    this.master = ctx.createGain();
    this.master.gain.value = 0.85;
    this.master.connect(ctx.destination);

    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -18;
    comp.ratio.value = 8;
    comp.connect(this.master);

    this.sfxBus = ctx.createGain();
    this.sfxBus.gain.value = 0.75;
    this.sfxBus.connect(comp);

    this.musicBus = ctx.createGain();
    this.musicBus.gain.value = 0.32;
    this.musicBus.connect(comp);

    const len = ctx.sampleRate * 2;
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    this.noiseBuf = buf;
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master) this.master.gain.value = m ? 0 : 0.85;
  }

  private noise(dur: number, gain: number, filter: number, type: BiquadFilterType = 'lowpass', sweepTo?: number) {
    const ctx = this.ctx;
    if (!ctx || !this.noiseBuf || !this.sfxBus) return;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    src.loop = true;
    const f = ctx.createBiquadFilter();
    f.type = type;
    f.frequency.setValueAtTime(filter, ctx.currentTime);
    if (sweepTo) f.frequency.exponentialRampToValueAtTime(Math.max(40, sweepTo), ctx.currentTime + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(gain, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.0008, ctx.currentTime + dur);
    src.connect(f).connect(g).connect(this.sfxBus);
    src.start();
    src.stop(ctx.currentTime + dur + 0.02);
  }

  private tone(freq: number, dur: number, gain: number, type: OscillatorType = 'sine', to?: number, bus?: GainNode) {
    const ctx = this.ctx;
    if (!ctx) return;
    const dest = bus ?? this.sfxBus;
    if (!dest) return;
    const o = ctx.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(freq, ctx.currentTime);
    if (to) o.frequency.exponentialRampToValueAtTime(Math.max(20, to), ctx.currentTime + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(gain, ctx.currentTime + 0.006);
    g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur);
    o.connect(g).connect(dest);
    o.start();
    o.stop(ctx.currentTime + dur + 0.02);
  }

  shoot(kind: string) {
    if (!this.ctx) return;
    switch (kind) {
      case 'rifle':
        this.noise(0.09, 0.32, 2600, 'bandpass', 700);
        this.tone(220, 0.07, 0.16, 'square', 70);
        break;
      case 'shotgun':
        this.noise(0.26, 0.5, 1600, 'lowpass', 180);
        this.tone(120, 0.2, 0.26, 'sawtooth', 40);
        break;
      case 'railgun':
        this.tone(1500, 0.32, 0.24, 'sawtooth', 120);
        this.noise(0.3, 0.25, 5000, 'highpass', 900);
        break;
      case 'launcher':
        this.tone(320, 0.18, 0.28, 'square', 90);
        this.noise(0.22, 0.3, 900, 'lowpass', 200);
        break;
    }
  }

  explosion(power = 1) {
    this.noise(0.55 * power, 0.55, 900, 'lowpass', 60);
    this.tone(90, 0.4 * power, 0.35, 'sine', 28);
  }

  hit() {
    this.noise(0.05, 0.18, 4200, 'bandpass', 1800);
  }

  crit() {
    this.tone(1400, 0.09, 0.16, 'square', 600);
    this.noise(0.06, 0.16, 6000, 'highpass');
  }

  enemyDeath() {
    this.noise(0.28, 0.3, 1500, 'lowpass', 120);
    this.tone(180, 0.22, 0.14, 'sawtooth', 50);
  }

  playerHurt() {
    this.tone(140, 0.28, 0.3, 'sawtooth', 60);
    this.noise(0.2, 0.28, 700, 'lowpass', 120);
  }

  reload() {
    this.noise(0.05, 0.2, 2400, 'bandpass');
    window.setTimeout(() => this.noise(0.06, 0.22, 1500, 'bandpass'), 160);
  }

  dash() {
    this.noise(0.24, 0.24, 2400, 'bandpass', 340);
    this.tone(600, 0.2, 0.1, 'sine', 1400);
  }

  pickup() {
    this.tone(660, 0.09, 0.16, 'triangle', 1200);
    window.setTimeout(() => this.tone(990, 0.1, 0.13, 'triangle', 1500), 60);
  }

  ui() {
    this.tone(520, 0.06, 0.12, 'square', 700);
  }

  waveStart() {
    this.tone(70, 1.4, 0.4, 'sawtooth', 46);
    this.tone(140, 1.0, 0.16, 'square', 90);
  }

  bossRoar() {
    this.tone(58, 2.2, 0.5, 'sawtooth', 32);
    this.noise(1.8, 0.4, 500, 'lowpass', 60);
  }

  gameOver() {
    this.tone(300, 2.4, 0.3, 'sawtooth', 40);
  }

  startMusic(intensity = 0) {
    this.init();
    if (!this.ctx || this.musicTimer !== null) return;
    const bassNotes = [55, 55, 73.42, 55, 65.41, 55, 49, 61.74];
    const tick = () => {
      if (!this.ctx || !this.musicBus) return;
      const i = this.step % 8;
      const f = bassNotes[i];
      this.tone(f, 0.34, 0.5, 'sawtooth', f * 0.98, this.musicBus);
      if (this.step % 4 === 0) this.tone(f * 2, 0.18, 0.12, 'square', f * 2, this.musicBus);
      if (intensity > 0 && this.step % 2 === 1) {
        const ctx = this.ctx;
        if (this.noiseBuf) {
          const src = ctx.createBufferSource();
          src.buffer = this.noiseBuf;
          const g = ctx.createGain();
          g.gain.setValueAtTime(0.12, ctx.currentTime);
          g.gain.exponentialRampToValueAtTime(0.0005, ctx.currentTime + 0.07);
          const bp = ctx.createBiquadFilter();
          bp.type = 'highpass';
          bp.frequency.value = 6000;
          src.connect(bp).connect(g).connect(this.musicBus);
          src.start();
          src.stop(ctx.currentTime + 0.09);
        }
      }
      this.step++;
    };
    tick();
    this.musicTimer = window.setInterval(tick, 250);
  }

  stopMusic() {
    if (this.musicTimer !== null) {
      window.clearInterval(this.musicTimer);
      this.musicTimer = null;
    }
  }

  setMusicIntensity(v: number) {
    if (this.musicBus) this.musicBus.gain.value = 0.22 + v * 0.22;
  }
}

export const audio = new AudioEngine();
