// Core types, tuning data and shared helpers for OBSIDIAN PROTOCOL

export interface Vec {
  x: number;
  y: number;
}

export type WeaponId = 'rifle' | 'shotgun' | 'railgun' | 'launcher';

export interface WeaponDef {
  id: WeaponId;
  name: string;
  code: string;
  damage: number;
  rof: number; // ms between shots
  mag: number;
  reload: number; // ms
  pellets: number;
  spread: number; // radians
  speed: number;
  pierce: number;
  auto: boolean;
  bulletSize: number;
  color: string;
  glow: string;
  knockback: number;
  recoil: number;
  shake: number;
  unlockWave: number;
  explosive?: number;
  tracer: number;
}

export const WEAPONS: Record<WeaponId, WeaponDef> = {
  rifle: {
    id: 'rifle',
    name: '毒蛇-7 突击步枪',
    code: 'VIPER-7',
    damage: 13,
    rof: 88,
    mag: 32,
    reload: 1150,
    pellets: 1,
    spread: 0.045,
    speed: 1250,
    pierce: 0,
    auto: true,
    bulletSize: 3,
    color: '#ffe9a8',
    glow: '#ffb436',
    knockback: 90,
    recoil: 1.6,
    shake: 1.6,
    unlockWave: 1,
    tracer: 22,
  },
  shotgun: {
    id: 'shotgun',
    name: '破门者 霰弹枪',
    code: 'BREACHER',
    damage: 11,
    rof: 720,
    mag: 7,
    reload: 1600,
    pellets: 9,
    spread: 0.3,
    speed: 980,
    pierce: 0,
    auto: false,
    bulletSize: 3.4,
    color: '#ffd0a0',
    glow: '#ff6a2a',
    knockback: 330,
    recoil: 7,
    shake: 7,
    unlockWave: 2,
    tracer: 14,
  },
  railgun: {
    id: 'railgun',
    name: '长枪 电磁轨道炮',
    code: 'LANCE',
    damage: 130,
    rof: 1250,
    mag: 4,
    reload: 2000,
    pellets: 1,
    spread: 0.002,
    speed: 3400,
    pierce: 8,
    auto: false,
    bulletSize: 5,
    color: '#dff6ff',
    glow: '#3fd7ff',
    knockback: 220,
    recoil: 6,
    shake: 9,
    unlockWave: 4,
    tracer: 60,
  },
  launcher: {
    id: 'launcher',
    name: '灰烬 榴弹发射器',
    code: 'CINDER',
    damage: 60,
    rof: 950,
    mag: 5,
    reload: 2100,
    pellets: 1,
    spread: 0.03,
    speed: 720,
    pierce: 0,
    auto: false,
    bulletSize: 7,
    color: '#ffc7f2',
    glow: '#ff3ea5',
    knockback: 160,
    recoil: 5,
    shake: 6,
    unlockWave: 6,
    explosive: 130,
    tracer: 10,
  },
};

export const WEAPON_ORDER: WeaponId[] = ['rifle', 'shotgun', 'railgun', 'launcher'];

export type EnemyKind = 'grunt' | 'drone' | 'charger' | 'bomber' | 'brute' | 'boss';

export interface EnemyDef {
  kind: EnemyKind;
  name: string;
  hp: number;
  speed: number;
  radius: number;
  damage: number;
  score: number;
  cost: number;
  color: string;
  glow: string;
  minWave: number;
}

export const ENEMIES: Record<EnemyKind, EnemyDef> = {
  grunt: {
    kind: 'grunt',
    name: '腐化步兵',
    hp: 42,
    speed: 118,
    radius: 15,
    damage: 9,
    score: 100,
    cost: 1,
    color: '#7be0a0',
    glow: '#2bff9a',
    minWave: 1,
  },
  drone: {
    kind: 'drone',
    name: '悬浮炮台',
    hp: 55,
    speed: 96,
    radius: 14,
    damage: 11,
    score: 180,
    cost: 2,
    color: '#9fd0ff',
    glow: '#3aa0ff',
    minWave: 2,
  },
  charger: {
    kind: 'charger',
    name: '突袭者',
    hp: 78,
    speed: 150,
    radius: 17,
    damage: 20,
    score: 260,
    cost: 3,
    color: '#ffcf7a',
    glow: '#ff9b23',
    minWave: 3,
  },
  bomber: {
    kind: 'bomber',
    name: '自爆虫',
    hp: 34,
    speed: 205,
    radius: 13,
    damage: 30,
    score: 220,
    cost: 2,
    color: '#ff9c9c',
    glow: '#ff2f4f',
    minWave: 4,
  },
  brute: {
    kind: 'brute',
    name: '重装屠夫',
    hp: 380,
    speed: 74,
    radius: 27,
    damage: 26,
    score: 700,
    cost: 6,
    color: '#c8a2ff',
    glow: '#8b3aff',
    minWave: 5,
  },
  boss: {
    kind: 'boss',
    name: '深渊主宰',
    hp: 2600,
    speed: 78,
    radius: 52,
    damage: 34,
    score: 6000,
    cost: 0,
    color: '#ff8fb0',
    glow: '#ff1f5a',
    minWave: 5,
  },
};

export interface UpgradeDef {
  id: string;
  name: string;
  desc: string;
  icon: string;
  rarity: 'common' | 'rare' | 'epic';
  apply: (s: PlayerStats) => void;
}

export interface PlayerStats {
  damageMul: number;
  fireRateMul: number;
  maxHp: number;
  speed: number;
  reloadMul: number;
  magMul: number;
  critChance: number;
  critMul: number;
  lifesteal: number;
  dashCd: number;
  pickupRange: number;
  armor: number;
  explosiveRounds: number;
}

export const BASE_STATS: PlayerStats = {
  damageMul: 1,
  fireRateMul: 1,
  maxHp: 100,
  speed: 268,
  reloadMul: 1,
  magMul: 1,
  critChance: 0.08,
  critMul: 2,
  lifesteal: 0,
  dashCd: 1500,
  pickupRange: 70,
  armor: 0,
  explosiveRounds: 0,
};

export const UPGRADES: UpgradeDef[] = [
  { id: 'dmg', name: '穿甲弹芯', desc: '所有武器伤害 +18%', icon: '◆', rarity: 'common', apply: (s) => { s.damageMul *= 1.18; } },
  { id: 'rof', name: '高速枪机', desc: '射速 +15%', icon: '⇉', rarity: 'common', apply: (s) => { s.fireRateMul *= 1.15; } },
  { id: 'hp', name: '纳米装甲板', desc: '最大生命 +30 并立即回满', icon: '✚', rarity: 'common', apply: (s) => { s.maxHp += 30; } },
  { id: 'spd', name: '外骨骼伺服', desc: '移动速度 +10%', icon: '⇅', rarity: 'common', apply: (s) => { s.speed *= 1.1; } },
  { id: 'reload', name: '快速弹匣', desc: '换弹速度 +22%', icon: '⟳', rarity: 'common', apply: (s) => { s.reloadMul *= 0.78; } },
  { id: 'mag', name: '扩容弹鼓', desc: '弹匣容量 +40%', icon: '▤', rarity: 'rare', apply: (s) => { s.magMul *= 1.4; } },
  { id: 'crit', name: '弱点扫描仪', desc: '暴击率 +14%', icon: '◎', rarity: 'rare', apply: (s) => { s.critChance += 0.14; } },
  { id: 'critdmg', name: '致命计算', desc: '暴击伤害 +60%', icon: '✦', rarity: 'rare', apply: (s) => { s.critMul += 0.6; } },
  { id: 'ls', name: '寄生纳米虫', desc: '吸血 +4% 造成伤害', icon: '❥', rarity: 'rare', apply: (s) => { s.lifesteal += 0.04; } },
  { id: 'dash', name: '相位推进器', desc: '闪避冷却 -30%', icon: '»', rarity: 'rare', apply: (s) => { s.dashCd *= 0.7; } },
  { id: 'armor', name: '能量护盾层', desc: '受到伤害减免 +12%', icon: '⛨', rarity: 'epic', apply: (s) => { s.armor = Math.min(0.7, s.armor + 0.12); } },
  { id: 'boom', name: '高爆弹头', desc: '子弹命中产生小型爆炸', icon: '✸', rarity: 'epic', apply: (s) => { s.explosiveRounds += 1; } },
  { id: 'magnet', name: '拾取磁场', desc: '拾取范围 +120%', icon: '◉', rarity: 'common', apply: (s) => { s.pickupRange *= 2.2; } },
];

// ---------- helpers ----------
export const rand = (a: number, b: number) => a + Math.random() * (b - a);
export const randInt = (a: number, b: number) => Math.floor(rand(a, b + 1));
export const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const dist2 = (ax: number, ay: number, bx: number, by: number) => {
  const dx = ax - bx;
  const dy = ay - by;
  return dx * dx + dy * dy;
};
export const angleLerp = (a: number, b: number, t: number) => {
  let d = b - a;
  while (d > Math.PI) d -= Math.PI * 2;
  while (d < -Math.PI) d += Math.PI * 2;
  return a + d * t;
};
export const pick = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];
