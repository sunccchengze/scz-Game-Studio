import {
  BASE_STATS,
  ENEMIES,
  UPGRADES,
  WEAPONS,
  WEAPON_ORDER,
  clamp,
  dist2,
  lerp,
  pick,
  rand,
  randInt,
  type EnemyDef,
  type EnemyKind,
  type PlayerStats,
  type UpgradeDef,
  type WeaponId,
} from './core';
import { audio } from './audio';

export interface Bullet {
  x: number; y: number; px: number; py: number;
  vx: number; vy: number;
  dmg: number; life: number; pierce: number;
  size: number; color: string; glow: string;
  from: 'player' | 'enemy';
  crit: boolean; explosive: number; knockback: number; tracer: number;
  hits: number[];
}

export interface Enemy {
  id: number; kind: EnemyKind; def: EnemyDef;
  x: number; y: number; vx: number; vy: number;
  hp: number; maxHp: number; angle: number;
  radius: number; damage: number;
  state: 'idle' | 'seek' | 'windup' | 'dash' | 'recover' | 'attack';
  t: number; cd: number; flash: number; spawnT: number;
  wobble: number; hitCd: number; phase: number;
  dashVX: number; dashVY: number; elite: boolean;
  stuckT: number; avoidT: number; avoidDir: number;
}

export interface Particle {
  x: number; y: number; vx: number; vy: number;
  life: number; maxLife: number; size: number;
  color: string; kind: 'spark' | 'smoke' | 'ring' | 'debris' | 'text' | 'flash';
  text?: string; drag: number; rot: number; vr: number;
}

export interface Pickup {
  x: number; y: number; type: 'health' | 'ammo' | 'shield'; t: number; vx: number; vy: number;
}

export interface Obstacle { x: number; y: number; w: number; h: number; hue: number }

export interface Marker { x: number; y: number; t: number; max: number }

export interface HudState {
  hp: number; maxHp: number; shield: number;
  ammo: number; mag: number; reloading: boolean; reloadPct: number;
  weapon: WeaponId; unlocked: WeaponId[];
  wave: number; score: number; combo: number; comboPct: number;
  kills: number; enemiesLeft: number;
  dashPct: number; banner: string; bannerSub: string; bannerT: number;
  bossHp: number; bossMax: number; bossName: string;
  waveState: WaveState; countdown: number;
}

export type WaveState = 'countdown' | 'active' | 'cleared' | 'upgrade' | 'dead';

const WORLD_W = 2600;
const WORLD_H = 1800;
const MAX_PARTICLES = 1100;

export class Game {
  canvas: HTMLCanvasElement;
  W = 1280;
  H = 720;
  dpr = 1;

  // world
  worldW = WORLD_W;
  worldH = WORLD_H;
  obstacles: Obstacle[] = [];

  // entities
  bullets: Bullet[] = [];
  enemies: Enemy[] = [];
  particles: Particle[] = [];
  pickups: Pickup[] = [];
  markers: Marker[] = [];
  private nextId = 1;

  // player
  px = WORLD_W / 2;
  py = WORLD_H / 2;
  pvx = 0;
  pvy = 0;
  pangle = 0;
  hp = 100;
  shield = 0;
  stats: PlayerStats = { ...BASE_STATS };
  weapon: WeaponId = 'rifle';
  unlocked: WeaponId[] = ['rifle'];
  ammo: Record<WeaponId, number> = { rifle: 32, shotgun: 7, railgun: 4, launcher: 5 };
  reloading = false;
  reloadT = 0;
  reloadDur = 0;
  shotCd = 0;
  dashCd = 0;
  dashT = 0;
  invuln = 0;
  recoil = 0;
  walkT = 0;
  hurtFlash = 0;
  healFlash = 0;

  // camera
  camX = WORLD_W / 2;
  camY = WORLD_H / 2;
  shake = 0;
  shakeX = 0;
  shakeY = 0;
  timeScale = 1;
  hitStop = 0;

  // progression
  wave = 0;
  waveState: WaveState = 'countdown';
  waveTimer = 3;
  clearT = 0;
  spawnQueue: { kind: EnemyKind; delay: number; elite: boolean; sx?: number; sy?: number }[] = [];
  score = 0;
  kills = 0;
  combo = 0;
  comboT = 0;
  elapsed = 0;
  banner = '';
  bannerSub = '';
  bannerT = 0;
  boss: Enemy | null = null;

  // input
  keys = new Set<string>();
  mouseX = 0;
  mouseY = 0;
  mouseDown = false;
  paused = false;
  running = false;

  // callbacks
  onHud: (h: HudState) => void = () => {};
  onUpgrade: (opts: UpgradeDef[]) => void = () => {};
  onGameOver: (s: { score: number; wave: number; kills: number; time: number }) => void = () => {};

  private raf = 0;
  private last = 0;
  private hudTick = 0;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.buildArena();
  }

  // ---------------- setup ----------------
  buildArena() {
    this.obstacles = [];
    const t = 40;
    this.obstacles.push({ x: 0, y: 0, w: this.worldW, h: t, hue: 0 });
    this.obstacles.push({ x: 0, y: this.worldH - t, w: this.worldW, h: t, hue: 0 });
    this.obstacles.push({ x: 0, y: 0, w: t, h: this.worldH, hue: 0 });
    this.obstacles.push({ x: this.worldW - t, y: 0, w: t, h: this.worldH, hue: 0 });

    const blocks: [number, number, number, number][] = [
      [320, 300, 220, 90], [2060, 300, 220, 90],
      [320, 1410, 220, 90], [2060, 1410, 220, 90],
      [640, 700, 90, 400], [1870, 700, 90, 400],
      [1120, 250, 360, 80], [1120, 1470, 360, 80],
      [1180, 780, 240, 240],
      [880, 480, 90, 90], [1630, 480, 90, 90],
      [880, 1230, 90, 90], [1630, 1230, 90, 90],
      [400, 860, 130, 130], [2070, 860, 130, 130],
    ];
    for (const [x, y, w, h] of blocks) this.obstacles.push({ x, y, w, h, hue: rand(180, 320) });
  }

  reset() {
    this.bullets = [];
    this.enemies = [];
    this.particles = [];
    this.pickups = [];
    this.markers = [];
    this.spawnQueue = [];
    this.boss = null;
    this.stats = { ...BASE_STATS };
    this.hp = this.stats.maxHp;
    this.shield = 0;
    this.px = this.worldW / 2;
    this.py = this.worldH / 2;
    this.pvx = this.pvy = 0;
    this.camX = this.px;
    this.camY = this.py;
    this.weapon = 'rifle';
    this.unlocked = ['rifle'];
    this.ammo = { rifle: 32, shotgun: 7, railgun: 4, launcher: 5 };
    this.reloading = false;
    this.shotCd = 0;
    this.dashCd = 0;
    this.dashT = 0;
    this.invuln = 1;
    this.wave = 0;
    this.score = 0;
    this.kills = 0;
    this.combo = 0;
    this.comboT = 0;
    this.elapsed = 0;
    this.waveState = 'countdown';
    this.waveTimer = 3.2;
    this.timeScale = 1;
    this.shake = 0;
    this.setBanner('准备作战', '第 1 波 即将来袭');
  }

  resize(w: number, h: number, dpr: number) {
    this.W = w;
    this.H = h;
    this.dpr = dpr;
  }

  start() {
    this.reset();
    this.running = true;
    this.paused = false;
    this.last = performance.now();
    cancelAnimationFrame(this.raf);
    this.raf = requestAnimationFrame(this.loop);
  }

  stop() {
    this.running = false;
    cancelAnimationFrame(this.raf);
  }

  private loop = (now: number) => {
    this.raf = requestAnimationFrame(this.loop);
    let dt = (now - this.last) / 1000;
    this.last = now;
    if (dt > 0.05) dt = 0.05;
    if (!this.paused && this.waveState !== 'upgrade' && this.waveState !== 'dead') {
      if (this.hitStop > 0) {
        this.hitStop -= dt;
        this.timeScale = lerp(this.timeScale, 0.12, 0.5);
      } else {
        this.timeScale = lerp(this.timeScale, 1, 0.12);
      }
      this.update(dt * this.timeScale, dt);
    } else {
      this.updateCamera(dt);
    }
    this.render();
    this.hudTick += dt;
    if (this.hudTick > 0.05) {
      this.hudTick = 0;
      this.onHud(this.hud());
    }
  };

  setBanner(main: string, sub = '') {
    this.banner = main;
    this.bannerSub = sub;
    this.bannerT = 2.6;
  }

  hud(): HudState {
    const def = WEAPONS[this.weapon];
    return {
      hp: Math.max(0, Math.round(this.hp)),
      maxHp: Math.round(this.stats.maxHp),
      shield: Math.round(this.shield),
      ammo: this.ammo[this.weapon],
      mag: this.magSize(def.id),
      reloading: this.reloading,
      reloadPct: this.reloading ? clamp(1 - this.reloadT / this.reloadDur, 0, 1) : 1,
      weapon: this.weapon,
      unlocked: [...this.unlocked],
      wave: Math.max(1, this.wave),
      score: Math.round(this.score),
      combo: this.combo,
      comboPct: clamp(this.comboT / 3, 0, 1),
      kills: this.kills,
      enemiesLeft: this.enemies.length + this.spawnQueue.length,
      dashPct: clamp(1 - this.dashCd / (this.stats.dashCd / 1000), 0, 1),
      banner: this.banner,
      bannerSub: this.bannerSub,
      bannerT: this.bannerT,
      bossHp: this.boss ? this.boss.hp : 0,
      bossMax: this.boss ? this.boss.maxHp : 0,
      bossName: this.boss ? this.boss.def.name : '',
      waveState: this.waveState,
      countdown: Math.max(0, this.waveTimer),
    };
  }

  magSize(id: WeaponId) {
    return Math.round(WEAPONS[id].mag * this.stats.magMul);
  }

  // ---------------- waves ----------------
  startWave(n: number) {
    this.wave = n;
    this.waveState = 'active';
    const isBoss = n % 5 === 0;
    const budget = 6 + n * 3.4;
    let spent = 0;
    const queue: { kind: EnemyKind; delay: number; elite: boolean }[] = [];
    const pool: EnemyKind[] = (['grunt', 'drone', 'charger', 'bomber', 'brute'] as EnemyKind[]).filter(
      (k) => ENEMIES[k].minWave <= n,
    );
    let delay = 0;
    while (spent < budget) {
      const k = pick(pool);
      const d = ENEMIES[k];
      if (spent + d.cost > budget + 3) break;
      spent += d.cost;
      const elite = n >= 4 && Math.random() < 0.1 + n * 0.012;
      queue.push({ kind: k, delay, elite });
      delay += rand(0.12, 0.5);
      if (queue.length % 6 === 0) delay += rand(1.4, 2.6);
    }
    if (isBoss) {
      queue.unshift({ kind: 'boss', delay: 1.2, elite: false });
      audio.bossRoar();
      this.setBanner('警告：主宰级目标接近', `第 ${n} 波 · BOSS 战`);
    } else {
      audio.waveStart();
      this.setBanner(`第 ${n} 波`, `敌对信号 ${queue.length} 个`);
    }
    this.spawnQueue = queue;
    audio.setMusicIntensity(clamp(n / 12, 0, 1));

    // weapon unlocks
    for (const id of WEAPON_ORDER) {
      const w = WEAPONS[id];
      if (w.unlockWave === n && !this.unlocked.includes(id)) {
        this.unlocked.push(id);
        this.ammo[id] = this.magSize(id);
        this.setBanner('解锁新武器', w.name);
        audio.pickup();
      }
    }
  }

  private spawnPos(): { x: number; y: number } {
    for (let i = 0; i < 60; i++) {
      const a = rand(0, Math.PI * 2);
      const r = rand(560, 900);
      const x = clamp(this.px + Math.cos(a) * r, 90, this.worldW - 90);
      const y = clamp(this.py + Math.sin(a) * r, 90, this.worldH - 90);
      if (dist2(x, y, this.px, this.py) < 420 * 420) continue;
      let bad = false;
      for (const o of this.obstacles) {
        if (x > o.x - 40 && x < o.x + o.w + 40 && y > o.y - 40 && y < o.y + o.h + 40) { bad = true; break; }
      }
      if (!bad) return { x, y };
    }
    return { x: clamp(this.px + 600, 90, this.worldW - 90), y: this.py };
  }

  spawnEnemy(kind: EnemyKind, x: number, y: number, elite = false) {
    const def = ENEMIES[kind];
    const scale = 1 + (this.wave - 1) * 0.13;
    const e: Enemy = {
      id: this.nextId++,
      kind,
      def,
      x, y,
      vx: 0, vy: 0,
      hp: def.hp * scale * (elite ? 2.2 : 1),
      maxHp: def.hp * scale * (elite ? 2.2 : 1),
      angle: rand(0, Math.PI * 2),
      radius: def.radius * (elite ? 1.28 : 1),
      damage: def.damage * (1 + (this.wave - 1) * 0.05),
      state: 'seek',
      t: 0, cd: rand(0.4, 1.6), flash: 0, spawnT: 0.45,
      wobble: rand(0, 6.28), hitCd: 0, phase: 0,
      dashVX: 0, dashVY: 0,
      elite,
      stuckT: 0, avoidT: 0, avoidDir: Math.random() < 0.5 ? -1 : 1,
    };
    if (kind === 'boss') {
      e.hp = e.maxHp = def.hp * (1 + (this.wave / 5 - 1) * 0.6);
      this.boss = e;
    }
    this.enemies.push(e);
    this.burst(x, y, 16, elite ? '#ffd36e' : def.glow, 220);
  }

  // ---------------- update ----------------
  update(dt: number, realDt: number) {
    this.elapsed += dt;
    this.bannerT = Math.max(0, this.bannerT - realDt);
    if (this.comboT > 0) {
      this.comboT -= dt;
      if (this.comboT <= 0) this.combo = 0;
    }

    this.updateWave(dt);
    this.updatePlayer(dt);
    this.updateEnemies(dt);
    this.updateBullets(dt);
    this.updatePickups(dt);
    this.updateParticles(dt);
    this.updateCamera(realDt);

    for (let i = this.markers.length - 1; i >= 0; i--) {
      this.markers[i].t -= dt;
      if (this.markers[i].t <= 0) this.markers.splice(i, 1);
    }
  }

  updateWave(dt: number) {
    if (this.waveState === 'countdown') {
      this.waveTimer -= dt;
      if (this.waveTimer <= 0) this.startWave(this.wave + 1);
      return;
    }
    if (this.waveState === 'cleared') {
      this.clearT -= dt;
      if (this.clearT <= 0) {
        this.waveState = 'upgrade';
        const opts: UpgradeDef[] = [];
        const pool = [...UPGRADES];
        for (let i = 0; i < 3 && pool.length; i++) {
          const idx = randInt(0, pool.length - 1);
          opts.push(pool[idx]);
          pool.splice(idx, 1);
        }
        this.onUpgrade(opts);
      }
      return;
    }
    if (this.waveState !== 'active') return;

    for (let i = this.spawnQueue.length - 1; i >= 0; i--) {
      const s = this.spawnQueue[i];
      s.delay -= dt;
      if (s.delay <= -0.7 && s.sx !== undefined && s.sy !== undefined) {
        this.spawnEnemy(s.kind, s.sx, s.sy, s.elite);
        this.spawnQueue.splice(i, 1);
      } else if (s.delay <= 0 && s.sx === undefined) {
        const p = this.spawnPos();
        s.sx = p.x;
        s.sy = p.y;
        this.markers.push({ x: p.x, y: p.y, t: 0.7, max: 0.7 });
      }
    }

    if (this.spawnQueue.length === 0 && this.enemies.length === 0) {
      this.waveState = 'cleared';
      this.clearT = 1.5;
      this.boss = null;
      this.setBanner('区域肃清', '选择一项强化');
      audio.ui();
    }
  }

  chooseUpgrade(id: string) {
    const u = UPGRADES.find((x) => x.id === id);
    if (u) {
      const before = this.stats.maxHp;
      u.apply(this.stats);
      if (this.stats.maxHp > before) this.hp = this.stats.maxHp;
      this.hp = Math.min(this.stats.maxHp, this.hp + 25);
      audio.pickup();
    }
    this.waveState = 'countdown';
    this.waveTimer = 3.4;
    this.setBanner('强化已装载', `第 ${this.wave + 1} 波 准备中`);
  }

  // ---------------- player ----------------
  updatePlayer(dt: number) {
    const k = this.keys;
    let mx = 0;
    let my = 0;
    if (k.has('w') || k.has('arrowup')) my -= 1;
    if (k.has('s') || k.has('arrowdown')) my += 1;
    if (k.has('a') || k.has('arrowleft')) mx -= 1;
    if (k.has('d') || k.has('arrowright')) mx += 1;
    const len = Math.hypot(mx, my) || 1;
    mx /= len;
    my /= len;

    const worldMouse = this.screenToWorld(this.mouseX, this.mouseY);
    this.pangle = Math.atan2(worldMouse.y - this.py, worldMouse.x - this.px);

    if (this.dashT > 0) {
      this.dashT -= dt;
      this.invuln = Math.max(this.invuln, 0.06);
      if (Math.random() < 0.7) {
        this.particles.push({
          x: this.px, y: this.py, vx: rand(-20, 20), vy: rand(-20, 20),
          life: 0.35, maxLife: 0.35, size: 16, color: '#4ff0ff', kind: 'smoke', drag: 3, rot: 0, vr: 0,
        });
      }
    } else {
      const target = this.stats.speed * (this.reloading ? 0.82 : 1);
      this.pvx = lerp(this.pvx, mx * target, 1 - Math.pow(0.0009, dt));
      this.pvy = lerp(this.pvy, my * target, 1 - Math.pow(0.0009, dt));
    }

    if (this.dashCd > 0) this.dashCd -= dt;
    if (this.invuln > 0) this.invuln -= dt;
    if (this.shotCd > 0) this.shotCd -= dt;
    this.recoil = lerp(this.recoil, 0, 1 - Math.pow(0.002, dt));
    this.hurtFlash = Math.max(0, this.hurtFlash - dt * 2.4);
    this.healFlash = Math.max(0, this.healFlash - dt * 2.4);
    if (Math.hypot(this.pvx, this.pvy) > 40) this.walkT += dt * 9;

    this.moveCircle('player', dt);

    if (this.reloading) {
      this.reloadT -= dt;
      if (this.reloadT <= 0) {
        this.reloading = false;
        this.ammo[this.weapon] = this.magSize(this.weapon);
      }
    }

    const def = WEAPONS[this.weapon];
    if (this.mouseDown && this.shotCd <= 0 && !this.reloading && this.waveState !== 'dead') {
      if (this.ammo[this.weapon] > 0) {
        this.fire(def);
        if (!def.auto) this.mouseDown = false;
      } else {
        this.beginReload();
      }
    }

    // shield regen trickle
    if (this.shield > 0) this.shield = Math.max(0, this.shield - dt * 1.2);
  }

  beginReload() {
    if (this.reloading || this.ammo[this.weapon] >= this.magSize(this.weapon)) return;
    this.reloading = true;
    this.reloadDur = (WEAPONS[this.weapon].reload * this.stats.reloadMul) / 1000;
    this.reloadT = this.reloadDur;
    audio.reload();
  }

  switchWeapon(id: WeaponId) {
    if (!this.unlocked.includes(id) || this.weapon === id) return;
    this.weapon = id;
    this.reloading = false;
    this.shotCd = Math.max(this.shotCd, 0.18);
    audio.ui();
  }

  cycleWeapon(dir: number) {
    const list = WEAPON_ORDER.filter((w) => this.unlocked.includes(w));
    const i = list.indexOf(this.weapon);
    this.switchWeapon(list[(i + dir + list.length) % list.length]);
  }

  dash() {
    if (this.dashCd > 0 || this.dashT > 0) return;
    let mx = 0;
    let my = 0;
    const k = this.keys;
    if (k.has('w') || k.has('arrowup')) my -= 1;
    if (k.has('s') || k.has('arrowdown')) my += 1;
    if (k.has('a') || k.has('arrowleft')) mx -= 1;
    if (k.has('d') || k.has('arrowright')) mx += 1;
    if (!mx && !my) { mx = Math.cos(this.pangle); my = Math.sin(this.pangle); }
    const l = Math.hypot(mx, my) || 1;
    const spd = 1150;
    this.pvx = (mx / l) * spd;
    this.pvy = (my / l) * spd;
    this.dashT = 0.19;
    this.dashCd = this.stats.dashCd / 1000;
    this.shake = Math.max(this.shake, 4);
    audio.dash();
    this.burst(this.px, this.py, 14, '#4ff0ff', 260);
  }

  fire(def: typeof WEAPONS[WeaponId]) {
    this.ammo[this.weapon]--;
    this.shotCd = def.rof / 1000 / this.stats.fireRateMul;
    const muzzle = 26;
    const bx = this.px + Math.cos(this.pangle) * muzzle;
    const by = this.py + Math.sin(this.pangle) * muzzle;
    for (let i = 0; i < def.pellets; i++) {
      const crit = Math.random() < this.stats.critChance;
      const a = this.pangle + rand(-def.spread, def.spread) + this.recoil * 0.02;
      const spd = def.speed * rand(0.94, 1.06);
      this.bullets.push({
        x: bx, y: by, px: bx, py: by,
        vx: Math.cos(a) * spd, vy: Math.sin(a) * spd,
        dmg: def.damage * this.stats.damageMul * (crit ? this.stats.critMul : 1),
        life: def.id === 'railgun' ? 0.7 : 1.6,
        pierce: def.pierce,
        size: def.bulletSize * (crit ? 1.35 : 1),
        color: def.color, glow: def.glow,
        from: 'player',
        crit,
        explosive: def.explosive ?? (this.stats.explosiveRounds > 0 ? 60 + this.stats.explosiveRounds * 14 : 0),
        knockback: def.knockback,
        tracer: def.tracer,
        hits: [],
      });
    }
    // muzzle flash
    this.particles.push({
      x: bx, y: by, vx: 0, vy: 0, life: 0.07, maxLife: 0.07,
      size: def.id === 'shotgun' ? 52 : 34, color: def.glow, kind: 'flash', drag: 0, rot: this.pangle, vr: 0,
    });
    for (let i = 0; i < (def.id === 'shotgun' ? 14 : 5); i++) {
      const a = this.pangle + rand(-0.45, 0.45);
      this.particles.push({
        x: bx, y: by, vx: Math.cos(a) * rand(120, 460), vy: Math.sin(a) * rand(120, 460),
        life: rand(0.12, 0.3), maxLife: 0.3, size: rand(1.5, 3.5), color: def.glow, kind: 'spark', drag: 4, rot: 0, vr: 0,
      });
    }
    this.recoil = def.recoil;
    this.pvx -= Math.cos(this.pangle) * def.knockback * 0.25;
    this.pvy -= Math.sin(this.pangle) * def.knockback * 0.25;
    this.shake = Math.max(this.shake, def.shake);
    audio.shoot(def.id);
  }

  // ---------------- movement/collision ----------------
  moveCircle(who: 'player' | Enemy, dt: number) {
    const r = who === 'player' ? 15 : (who as Enemy).radius;
    let x = who === 'player' ? this.px : (who as Enemy).x;
    let y = who === 'player' ? this.py : (who as Enemy).y;
    const vx = who === 'player' ? this.pvx : (who as Enemy).vx;
    const vy = who === 'player' ? this.pvy : (who as Enemy).vy;
    x += vx * dt;
    y += vy * dt;
    for (const o of this.obstacles) {
      const cx = clamp(x, o.x, o.x + o.w);
      const cy = clamp(y, o.y, o.y + o.h);
      const dx = x - cx;
      const dy = y - cy;
      const d = Math.hypot(dx, dy);
      if (d < r) {
        if (d === 0) { x = o.x - r; continue; }
        const push = (r - d) / d;
        x += dx * push;
        y += dy * push;
      }
    }
    x = clamp(x, r, this.worldW - r);
    y = clamp(y, r, this.worldH - r);
    if (who === 'player') { this.px = x; this.py = y; }
    else { (who as Enemy).x = x; (who as Enemy).y = y; }
  }

  lineBlocked(x1: number, y1: number, x2: number, y2: number) {
    const steps = 10;
    for (let i = 1; i < steps; i++) {
      const t = i / steps;
      const x = lerp(x1, x2, t);
      const y = lerp(y1, y2, t);
      for (const o of this.obstacles) {
        if (x > o.x && x < o.x + o.w && y > o.y && y < o.y + o.h) return true;
      }
    }
    return false;
  }

  // ---------------- enemies ----------------
  updateEnemies(dt: number) {
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const e = this.enemies[i];
      e.t += dt;
      e.flash = Math.max(0, e.flash - dt * 4);
      e.hitCd = Math.max(0, e.hitCd - dt);
      e.cd -= dt;
      e.wobble += dt * 4;
      if (e.spawnT > 0) { e.spawnT -= dt; e.vx *= 0.8; e.vy *= 0.8; continue; }

      const dx = this.px - e.x;
      const dy = this.py - e.y;
      const d = Math.hypot(dx, dy) || 1;
      let nx = dx / d;
      let ny = dy / d;
      e.angle = Math.atan2(dy, dx);
      const spd = e.def.speed * (e.elite ? 1.15 : 1);

      // wall-avoidance steering: slide around cover instead of pressing into it
      if (e.avoidT > 0) {
        e.avoidT -= dt;
        const a = Math.atan2(ny, nx) + e.avoidDir * 1.2;
        nx = Math.cos(a);
        ny = Math.sin(a);
      }
      const prevX = e.x;
      const prevY = e.y;

      switch (e.kind) {
        case 'grunt': {
          e.vx = lerp(e.vx, nx * spd, 0.08);
          e.vy = lerp(e.vy, ny * spd, 0.08);
          break;
        }
        case 'drone': {
          const want = 320;
          const dir = d > want ? 1 : -1;
          const strafe = Math.sin(e.t * 1.4 + e.wobble) * 0.9;
          e.vx = lerp(e.vx, (nx * dir - ny * strafe) * spd, 0.06);
          e.vy = lerp(e.vy, (ny * dir + nx * strafe) * spd, 0.06);
          if (e.cd <= 0 && d < 620 && !this.lineBlocked(e.x, e.y, this.px, this.py)) {
            e.cd = rand(1.4, 2.2);
            this.enemyShot(e, e.angle, 340, e.damage);
          }
          break;
        }
        case 'charger': {
          if (e.state === 'seek') {
            e.vx = lerp(e.vx, nx * spd, 0.06);
            e.vy = lerp(e.vy, ny * spd, 0.06);
            if (d < 340 && !this.lineBlocked(e.x, e.y, this.px, this.py)) { e.state = 'windup'; e.cd = 0.65; }
          } else if (e.state === 'windup') {
            e.vx *= 0.86; e.vy *= 0.86;
            if (e.cd <= 0) {
              e.state = 'dash';
              e.cd = 0.42;
              e.dashVX = nx * 880;
              e.dashVY = ny * 880;
              this.burst(e.x, e.y, 10, e.def.glow, 200);
            }
          } else if (e.state === 'dash') {
            e.vx = e.dashVX; e.vy = e.dashVY;
            if (e.cd <= 0) { e.state = 'recover'; e.cd = 0.55; }
          } else {
            e.vx *= 0.8; e.vy *= 0.8;
            if (e.cd <= 0) e.state = 'seek';
          }
          break;
        }
        case 'bomber': {
          e.vx = lerp(e.vx, nx * spd, 0.1);
          e.vy = lerp(e.vy, ny * spd, 0.1);
          if (d < 52) { this.killEnemy(i, false); continue; }
          break;
        }
        case 'brute': {
          e.vx = lerp(e.vx, nx * spd, 0.04);
          e.vy = lerp(e.vy, ny * spd, 0.04);
          if (e.cd <= 0 && d < 300) {
            e.cd = 2.6;
            for (let s = 0; s < 8; s++) this.enemyShot(e, e.angle + (s - 3.5) * 0.16, 280, e.damage * 0.4);
          }
          break;
        }
        case 'boss': {
          this.updateBoss(e, dt, nx, ny, d);
          break;
        }
      }

      // separation
      for (const o of this.enemies) {
        if (o === e) continue;
        const ox = e.x - o.x;
        const oy = e.y - o.y;
        const od2 = ox * ox + oy * oy;
        const rr = e.radius + o.radius;
        if (od2 < rr * rr && od2 > 0.01) {
          const od = Math.sqrt(od2);
          const f = ((rr - od) / od) * 34;
          e.vx += ox * f * dt * 6;
          e.vy += oy * f * dt * 6;
        }
      }

      this.moveCircle(e, dt);

      // stuck detection -> flank, then relocate as a last resort
      const want = Math.hypot(e.vx, e.vy);
      const moved = Math.hypot(e.x - prevX, e.y - prevY) / (dt || 1 / 60);
      if (want > 45 && moved < want * 0.5) {
        e.stuckT += dt;
        if (e.avoidT <= 0 && e.stuckT > 0.3) {
          e.avoidT = rand(0.6, 1.3);
          if (Math.random() < 0.25) e.avoidDir *= -1;
        }
        if (e.stuckT > 5.5 && e.kind !== 'boss') {
          const p = this.spawnPos();
          this.burst(e.x, e.y, 12, e.def.glow, 200);
          e.x = p.x;
          e.y = p.y;
          e.vx = e.vy = 0;
          e.spawnT = 0.4;
          e.stuckT = 0;
          this.markers.push({ x: p.x, y: p.y, t: 0.4, max: 0.4 });
        }
      } else {
        e.stuckT = Math.max(0, e.stuckT - dt * 0.8);
      }

      // melee contact
      if (e.kind !== 'drone' && e.hitCd <= 0) {
        const rr = e.radius + 15;
        if (dist2(e.x, e.y, this.px, this.py) < rr * rr) {
          this.damagePlayer(e.damage * (e.state === 'dash' ? 1.5 : 1));
          e.hitCd = 0.75;
          const a = Math.atan2(this.py - e.y, this.px - e.x);
          this.pvx += Math.cos(a) * 280;
          this.pvy += Math.sin(a) * 280;
          if (e.state === 'dash') { e.state = 'recover'; e.cd = 0.7; }
        }
      }
    }
  }

  updateBoss(e: Enemy, _dt: number, nx: number, ny: number, d: number) {
    const hpPct = e.hp / e.maxHp;
    const rage = hpPct < 0.4 ? 1.6 : hpPct < 0.7 ? 1.25 : 1;
    if (e.state === 'seek') {
      const want = 300;
      const dir = d > want ? 1 : -0.6;
      const strafe = Math.sin(e.t * 0.7) * 0.8;
      e.vx = lerp(e.vx, (nx * dir - ny * strafe) * e.def.speed * rage, 0.03);
      e.vy = lerp(e.vy, (ny * dir + nx * strafe) * e.def.speed * rage, 0.03);
      if (e.cd <= 0) {
        e.phase = randInt(0, 3);
        e.state = 'windup';
        e.cd = 0.7;
        e.t = 0;
      }
    } else if (e.state === 'windup') {
      e.vx *= 0.9; e.vy *= 0.9;
      if (e.cd <= 0) { e.state = 'attack'; e.cd = e.phase === 1 ? 2.4 : e.phase === 3 ? 0.9 : 1.2; e.t = 0; }
    } else if (e.state === 'attack') {
      if (e.phase === 0) {
        // radial burst
        if (e.t > 0.25) {
          e.t = 0;
          const n = 18;
          const off = rand(0, 1);
          for (let i = 0; i < n; i++) this.enemyShot(e, (i / n) * Math.PI * 2 + off, 300, e.damage * 0.5);
        }
        e.vx *= 0.94; e.vy *= 0.94;
      } else if (e.phase === 1) {
        // spiral
        if (e.t > 0.06) {
          e.t = 0;
          e.wobble += 0.42;
          for (let i = 0; i < 3; i++) this.enemyShot(e, e.wobble + (i * Math.PI * 2) / 3, 340, e.damage * 0.4);
        }
        e.vx *= 0.96; e.vy *= 0.96;
      } else if (e.phase === 2) {
        // charge
        e.vx = lerp(e.vx, nx * 720 * rage, 0.12);
        e.vy = lerp(e.vy, ny * 720 * rage, 0.12);
      } else {
        // summon
        if (e.t > 0.4) {
          e.t = 0;
          const p = { x: e.x + rand(-160, 160), y: e.y + rand(-160, 160) };
          this.spawnEnemy(Math.random() < 0.5 ? 'grunt' : 'bomber', clamp(p.x, 80, this.worldW - 80), clamp(p.y, 80, this.worldH - 80));
        }
        e.vx *= 0.9; e.vy *= 0.9;
      }
      if (e.cd <= 0) { e.state = 'recover'; e.cd = 0.8 / rage; }
    } else {
      e.vx *= 0.92; e.vy *= 0.92;
      if (e.cd <= 0) { e.state = 'seek'; e.cd = rand(1.2, 2.2) / rage; }
    }
    if (Math.random() < 0.25) {
      this.particles.push({
        x: e.x + rand(-40, 40), y: e.y + rand(-40, 40), vx: rand(-10, 10), vy: rand(-40, -10),
        life: 0.6, maxLife: 0.6, size: rand(8, 20), color: '#ff2f6a', kind: 'smoke', drag: 1, rot: 0, vr: 0,
      });
    }
  }

  enemyShot(e: Enemy, angle: number, speed: number, dmg: number) {
    this.bullets.push({
      x: e.x + Math.cos(angle) * (e.radius + 6),
      y: e.y + Math.sin(angle) * (e.radius + 6),
      px: e.x, py: e.y,
      vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed,
      dmg, life: 3.2, pierce: 0, size: e.kind === 'boss' ? 7 : 5,
      color: '#ffd2e6', glow: e.def.glow, from: 'enemy', crit: false,
      explosive: 0, knockback: 0, tracer: 8, hits: [],
    });
    audio.hit();
  }

  enemyExplode(e: Enemy, radius: number, dmg: number) {
    this.explosionAt(e.x, e.y, radius, dmg, 'enemy');
  }

  explosionAt(x: number, y: number, radius: number, dmg: number, from: 'player' | 'enemy') {
    audio.explosion(radius / 130);
    this.shake = Math.max(this.shake, 8 + radius * 0.03);
    this.particles.push({ x, y, vx: 0, vy: 0, life: 0.4, maxLife: 0.4, size: radius, color: '#ffb347', kind: 'ring', drag: 0, rot: 0, vr: 0 });
    for (let i = 0; i < 26; i++) {
      const a = rand(0, Math.PI * 2);
      const s = rand(80, 620);
      this.particles.push({
        x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s,
        life: rand(0.25, 0.7), maxLife: 0.7, size: rand(2, 6),
        color: pick(['#fff2b0', '#ff9d3a', '#ff5722']), kind: 'spark', drag: 2.4, rot: 0, vr: 0,
      });
    }
    for (let i = 0; i < 12; i++) {
      const a = rand(0, Math.PI * 2);
      this.particles.push({
        x: x + Math.cos(a) * rand(0, radius * 0.5), y: y + Math.sin(a) * rand(0, radius * 0.5),
        vx: Math.cos(a) * rand(10, 70), vy: Math.sin(a) * rand(10, 70) - 20,
        life: rand(0.5, 1.1), maxLife: 1.1, size: rand(16, 40), color: '#3a2a24', kind: 'smoke', drag: 1.6, rot: 0, vr: 0,
      });
    }
    if (from === 'player') {
      for (let i = this.enemies.length - 1; i >= 0; i--) {
        const e = this.enemies[i];
        const dd = Math.hypot(e.x - x, e.y - y);
        if (dd < radius + e.radius) {
          const f = 1 - dd / (radius + e.radius);
          this.hurtEnemy(i, dmg * f, false, (e.x - x) / (dd || 1) * 260 * f, (e.y - y) / (dd || 1) * 260 * f);
        }
      }
    } else {
      const dd = Math.hypot(this.px - x, this.py - y);
      if (dd < radius + 16) this.damagePlayer(dmg * (1 - dd / (radius + 16)));
    }
  }

  // ---------------- bullets ----------------
  updateBullets(dt: number) {
    for (let i = this.bullets.length - 1; i >= 0; i--) {
      const b = this.bullets[i];
      b.px = b.x;
      b.py = b.y;
      b.x += b.vx * dt;
      b.y += b.vy * dt;
      b.life -= dt;
      let dead = b.life <= 0;

      if (!dead) {
        for (const o of this.obstacles) {
          if (b.x > o.x && b.x < o.x + o.w && b.y > o.y && b.y < o.y + o.h) {
            dead = true;
            this.sparkImpact(b.x, b.y, b.glow, 8);
            if (b.explosive) this.explosionAt(b.x, b.y, b.explosive, b.dmg * 0.7, b.from);
            break;
          }
        }
      }
      if (!dead && (b.x < 0 || b.y < 0 || b.x > this.worldW || b.y > this.worldH)) dead = true;

      if (!dead && b.from === 'player') {
        for (let j = this.enemies.length - 1; j >= 0; j--) {
          const e = this.enemies[j];
          if (b.hits.includes(e.id)) continue;
          const rr = e.radius + b.size;
          if (dist2(b.x, b.y, e.x, e.y) < rr * rr) {
            b.hits.push(e.id);
            const ang = Math.atan2(b.vy, b.vx);
            this.hurtEnemy(j, b.dmg, b.crit, Math.cos(ang) * b.knockback, Math.sin(ang) * b.knockback);
            this.sparkImpact(b.x, b.y, b.crit ? '#fff' : b.glow, b.crit ? 16 : 9);
            if (b.explosive) { this.explosionAt(b.x, b.y, b.explosive, b.dmg * 0.6, 'player'); dead = true; break; }
            if (b.pierce > 0) b.pierce--;
            else { dead = true; break; }
          }
        }
      } else if (!dead && b.from === 'enemy') {
        const rr = 15 + b.size;
        if (dist2(b.x, b.y, this.px, this.py) < rr * rr) {
          this.damagePlayer(b.dmg);
          this.sparkImpact(b.x, b.y, b.glow, 10);
          dead = true;
        }
      }
      if (dead) this.bullets.splice(i, 1);
    }
  }

  hurtEnemy(idx: number, dmg: number, crit: boolean, kx = 0, ky = 0) {
    const e = this.enemies[idx];
    if (!e) return;
    e.hp -= dmg;
    e.flash = 1;
    e.vx += kx;
    e.vy += ky;
    if (this.stats.lifesteal > 0) {
      const heal = dmg * this.stats.lifesteal;
      this.hp = Math.min(this.stats.maxHp, this.hp + heal);
      this.healFlash = 0.4;
    }
    this.particles.push({
      x: e.x + rand(-8, 8), y: e.y - e.radius - 6, vx: rand(-30, 30), vy: -70,
      life: 0.7, maxLife: 0.7, size: crit ? 22 : 15, color: crit ? '#ffdb4d' : '#ffffff',
      kind: 'text', text: crit ? `${Math.round(dmg)}!` : `${Math.round(dmg)}`, drag: 1.6, rot: 0, vr: 0,
    });
    if (crit) audio.crit(); else audio.hit();
    if (e.hp <= 0) this.killEnemy(idx, true);
  }

  killEnemy(idx: number, reward: boolean) {
    const e = this.enemies[idx];
    if (!e) return;
    this.enemies.splice(idx, 1);
    audio.enemyDeath();
    this.burst(e.x, e.y, e.kind === 'boss' ? 90 : 22, e.def.glow, e.kind === 'boss' ? 700 : 320);
    this.particles.push({ x: e.x, y: e.y, vx: 0, vy: 0, life: 0.4, maxLife: 0.4, size: e.radius * 2.6, color: e.def.glow, kind: 'ring', drag: 0, rot: 0, vr: 0 });
    if (e.kind === 'bomber') this.explosionAt(e.x, e.y, 110, e.damage * 0.8, 'enemy');
    if (reward) {
      this.kills++;
      this.combo++;
      this.comboT = 3;
      const mult = 1 + Math.min(this.combo, 30) * 0.06;
      this.score += e.def.score * mult * (e.elite ? 2 : 1);
      this.hitStop = e.kind === 'boss' ? 0.5 : e.kind === 'brute' ? 0.09 : 0.03;
      this.shake = Math.max(this.shake, e.kind === 'boss' ? 26 : 4);
    }
    if (e.kind === 'boss') {
      this.boss = null;
      this.setBanner('主宰已被摧毁', '战术优势确立');
      for (let i = 0; i < 5; i++) this.dropPickup(e.x + rand(-60, 60), e.y + rand(-60, 60), pick(['health', 'ammo', 'shield'] as const));
      audio.explosion(2.4);
    } else if (e.kind === 'brute') {
      for (let i = 0; i < 3; i++) this.spawnEnemy('grunt', e.x + rand(-50, 50), e.y + rand(-50, 50));
      this.dropPickup(e.x, e.y, 'shield');
    } else if (Math.random() < 0.19) {
      this.dropPickup(e.x, e.y, Math.random() < 0.5 ? 'health' : 'ammo');
    }
  }

  dropPickup(x: number, y: number, type: Pickup['type']) {
    this.pickups.push({ x, y, type, t: 0, vx: rand(-60, 60), vy: rand(-60, 60) });
  }

  damagePlayer(dmg: number) {
    if (this.invuln > 0 || this.waveState === 'dead') return;
    let d = dmg * (1 - this.stats.armor);
    if (this.shield > 0) {
      const abs = Math.min(this.shield, d);
      this.shield -= abs;
      d -= abs;
    }
    this.hp -= d;
    this.invuln = 0.42;
    this.hurtFlash = 1;
    this.shake = Math.max(this.shake, 9);
    this.combo = 0;
    audio.playerHurt();
    this.burst(this.px, this.py, 12, '#ff3b5c', 240);
    if (this.hp <= 0) {
      this.hp = 0;
      this.waveState = 'dead';
      this.timeScale = 1;
      audio.gameOver();
      audio.stopMusic();
      this.explosionAt(this.px, this.py, 150, 0, 'enemy');
      this.onGameOver({ score: Math.round(this.score), wave: this.wave, kills: this.kills, time: this.elapsed });
    }
  }

  updatePickups(dt: number) {
    const range = this.stats.pickupRange;
    for (let i = this.pickups.length - 1; i >= 0; i--) {
      const p = this.pickups[i];
      p.t += dt;
      const d = Math.hypot(this.px - p.x, this.py - p.y);
      if (d < range) {
        const pull = (1 - d / range) * 900;
        p.vx += ((this.px - p.x) / (d || 1)) * pull * dt;
        p.vy += ((this.py - p.y) / (d || 1)) * pull * dt;
      }
      p.vx *= 1 - 2 * dt;
      p.vy *= 1 - 2 * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      if (d < 26) {
        if (p.type === 'health') { this.hp = Math.min(this.stats.maxHp, this.hp + 28); this.healFlash = 1; }
        else if (p.type === 'ammo') {
          for (const w of this.unlocked) this.ammo[w] = this.magSize(w);
          this.reloading = false;
        } else this.shield = Math.min(80, this.shield + 45);
        audio.pickup();
        this.burst(p.x, p.y, 10, p.type === 'health' ? '#4dff9e' : p.type === 'ammo' ? '#ffd24d' : '#4fd2ff', 180);
        this.pickups.splice(i, 1);
      }
    }
  }

  // ---------------- fx ----------------
  burst(x: number, y: number, n: number, color: string, speed: number) {
    for (let i = 0; i < n; i++) {
      const a = rand(0, Math.PI * 2);
      const s = rand(speed * 0.2, speed);
      this.particles.push({
        x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s,
        life: rand(0.2, 0.6), maxLife: 0.6, size: rand(1.5, 4.2),
        color, kind: 'spark', drag: 3, rot: 0, vr: 0,
      });
    }
  }

  sparkImpact(x: number, y: number, color: string, n: number) {
    for (let i = 0; i < n; i++) {
      const a = rand(0, Math.PI * 2);
      const s = rand(60, 320);
      this.particles.push({
        x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s,
        life: rand(0.1, 0.3), maxLife: 0.3, size: rand(1, 3),
        color, kind: 'spark', drag: 4, rot: 0, vr: 0,
      });
    }
  }

  updateParticles(dt: number) {
    if (this.particles.length > MAX_PARTICLES) this.particles.splice(0, this.particles.length - MAX_PARTICLES);
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= dt;
      if (p.life <= 0) { this.particles.splice(i, 1); continue; }
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      const dr = 1 - p.drag * dt;
      p.vx *= dr;
      p.vy *= dr;
      if (p.kind === 'text') p.vy += 40 * dt;
      p.rot += p.vr * dt;
    }
  }

  updateCamera(dt: number) {
    const world = this.screenToWorld(this.mouseX, this.mouseY);
    const tx = this.px + (world.x - this.px) * 0.18;
    const ty = this.py + (world.y - this.py) * 0.18;
    const k = 1 - Math.pow(0.0001, dt);
    this.camX = lerp(this.camX, tx, k);
    this.camY = lerp(this.camY, ty, k);
    const halfW = this.W / 2 / this.zoom();
    const halfH = this.H / 2 / this.zoom();
    this.camX = clamp(this.camX, halfW, this.worldW - halfW);
    this.camY = clamp(this.camY, halfH, this.worldH - halfH);
    this.shake = Math.max(0, this.shake - dt * 34);
    const s = this.shake;
    this.shakeX = rand(-s, s);
    this.shakeY = rand(-s, s);
  }

  zoom() {
    return Math.max(this.W / 1500, this.H / 900, 0.62);
  }

  screenToWorld(sx: number, sy: number) {
    const z = this.zoom();
    return { x: this.camX + (sx - this.W / 2) / z, y: this.camY + (sy - this.H / 2) / z };
  }

  worldToScreen(wx: number, wy: number) {
    const z = this.zoom();
    return { x: (wx - this.camX) * z + this.W / 2 + this.shakeX, y: (wy - this.camY) * z + this.H / 2 + this.shakeY };
  }

  // render is injected by renderer module
  render: () => void = () => {};
}
