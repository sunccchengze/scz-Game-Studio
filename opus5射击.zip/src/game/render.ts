import type { Game, Enemy } from './engine';
import { WEAPONS, clamp } from './core';

export function attachRenderer(game: Game) {
  const ctx = game.canvas.getContext('2d')!;

  const drawEnemyShape = (e: Enemy, t: number) => {
    const r = e.radius;
    ctx.save();
    ctx.translate(e.x, e.y);
    ctx.rotate(e.angle);
    const flash = e.flash;
    const body = flash > 0.02 ? '#ffffff' : e.def.color;
    const glow = e.elite ? '#ffd45e' : e.def.glow;
    ctx.lineWidth = 2.5;
    ctx.strokeStyle = glow;
    ctx.fillStyle = body;
    ctx.globalAlpha = 1;

    switch (e.kind) {
      case 'grunt': {
        ctx.beginPath();
        ctx.moveTo(r * 1.2, 0);
        ctx.lineTo(-r * 0.7, r * 0.85);
        ctx.lineTo(-r * 0.3, 0);
        ctx.lineTo(-r * 0.7, -r * 0.85);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        break;
      }
      case 'drone': {
        const sp = t * 2.4;
        ctx.beginPath();
        for (let i = 0; i < 6; i++) {
          const a = (i / 6) * Math.PI * 2 + sp;
          const px = Math.cos(a) * r;
          const py = Math.sin(a) * r;
          i ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
        }
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = '#04121f';
        ctx.beginPath();
        ctx.arc(0, 0, r * 0.42, 0, 7);
        ctx.fill();
        ctx.fillStyle = glow;
        ctx.beginPath();
        ctx.arc(r * 0.25, 0, r * 0.22, 0, 7);
        ctx.fill();
        break;
      }
      case 'charger': {
        const stretch = e.state === 'dash' ? 1.45 : e.state === 'windup' ? 0.8 : 1;
        ctx.scale(stretch, 2 - stretch);
        ctx.beginPath();
        ctx.moveTo(r * 1.5, 0);
        ctx.lineTo(0, r * 0.9);
        ctx.lineTo(-r, r * 0.4);
        ctx.lineTo(-r, -r * 0.4);
        ctx.lineTo(0, -r * 0.9);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        if (e.state === 'windup') {
          ctx.globalAlpha = 0.5 + Math.sin(t * 40) * 0.3;
          ctx.strokeStyle = '#fff';
          ctx.lineWidth = 4;
          ctx.stroke();
        }
        break;
      }
      case 'bomber': {
        const p = 1 + Math.sin(t * 14) * 0.12;
        ctx.scale(p, p);
        ctx.beginPath();
        ctx.arc(0, 0, r, 0, 7);
        ctx.fill();
        ctx.stroke();
        ctx.strokeStyle = '#fff';
        ctx.globalAlpha = 0.5 + Math.sin(t * 14) * 0.5;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(0, 0, r * 0.55, 0, 7);
        ctx.stroke();
        break;
      }
      case 'brute': {
        ctx.rotate(Math.sin(t * 2) * 0.06);
        ctx.beginPath();
        ctx.moveTo(r, 0);
        ctx.lineTo(r * 0.4, r);
        ctx.lineTo(-r * 0.9, r * 0.75);
        ctx.lineTo(-r * 0.9, -r * 0.75);
        ctx.lineTo(r * 0.4, -r);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = '#1a0f2e';
        ctx.fillRect(-r * 0.2, -r * 0.5, r * 0.9, r);
        ctx.fillStyle = glow;
        ctx.fillRect(r * 0.2, -r * 0.16, r * 0.5, r * 0.32);
        break;
      }
      case 'boss': {
        ctx.save();
        ctx.rotate(t * 0.6);
        ctx.strokeStyle = glow;
        ctx.lineWidth = 4;
        for (let ring = 0; ring < 3; ring++) {
          ctx.globalAlpha = 0.35;
          ctx.beginPath();
          ctx.arc(0, 0, r * (0.7 + ring * 0.22), ring * 0.5, ring * 0.5 + 4.2);
          ctx.stroke();
        }
        ctx.restore();
        ctx.globalAlpha = 1;
        ctx.beginPath();
        for (let i = 0; i < 8; i++) {
          const a = (i / 8) * Math.PI * 2;
          const rr = i % 2 === 0 ? r : r * 0.62;
          const px = Math.cos(a + t * 0.3) * rr;
          const py = Math.sin(a + t * 0.3) * rr;
          i ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
        }
        ctx.closePath();
        ctx.fillStyle = flash > 0.02 ? '#fff' : '#2a0b1c';
        ctx.fill();
        ctx.strokeStyle = glow;
        ctx.lineWidth = 3;
        ctx.stroke();
        const eyeGlow = ctx.createRadialGradient(0, 0, 2, 0, 0, r * 0.7);
        eyeGlow.addColorStop(0, '#fff');
        eyeGlow.addColorStop(0.35, glow);
        eyeGlow.addColorStop(1, 'rgba(255,20,80,0)');
        ctx.fillStyle = eyeGlow;
        ctx.beginPath();
        ctx.arc(0, 0, r * 0.7, 0, 7);
        ctx.fill();
        break;
      }
    }
    ctx.restore();

    // hp bar
    if (e.hp < e.maxHp && e.kind !== 'boss') {
      const w = e.radius * 2.2;
      const pct = clamp(e.hp / e.maxHp, 0, 1);
      ctx.fillStyle = 'rgba(0,0,0,0.6)';
      ctx.fillRect(e.x - w / 2, e.y - e.radius - 13, w, 4.5);
      ctx.fillStyle = e.elite ? '#ffd45e' : '#ff4d6d';
      ctx.fillRect(e.x - w / 2, e.y - e.radius - 13, w * pct, 4.5);
    }
    if (e.elite) {
      ctx.strokeStyle = 'rgba(255,212,94,0.7)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(e.x, e.y, e.radius + 7 + Math.sin(t * 5) * 2, 0, 7);
      ctx.stroke();
    }
    if (e.spawnT > 0) {
      ctx.globalAlpha = clamp(e.spawnT / 0.45, 0, 1);
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(e.x, e.y, e.radius + (1 - e.spawnT / 0.45) * 40, 0, 7);
      ctx.stroke();
      ctx.globalAlpha = 1;
    }
  };

  game.render = () => {
    const W = game.W;
    const H = game.H;
    const t = game.elapsed;
    const z = game.zoom();

    ctx.setTransform(game.dpr, 0, 0, game.dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);

    // deep background
    const bg = ctx.createLinearGradient(0, 0, 0, H);
    bg.addColorStop(0, '#070a12');
    bg.addColorStop(1, '#0d0713');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, W, H);

    ctx.save();
    ctx.translate(W / 2 + game.shakeX, H / 2 + game.shakeY);
    ctx.scale(z, z);
    ctx.translate(-game.camX, -game.camY);

    const viewL = game.camX - W / 2 / z - 80;
    const viewT = game.camY - H / 2 / z - 80;
    const viewR = game.camX + W / 2 / z + 80;
    const viewB = game.camY + H / 2 / z + 80;

    // floor plate
    ctx.fillStyle = '#0b1020';
    ctx.fillRect(0, 0, game.worldW, game.worldH);

    // grid
    const gs = 100;
    ctx.lineWidth = 1;
    ctx.strokeStyle = 'rgba(70,120,190,0.10)';
    ctx.beginPath();
    for (let x = Math.floor(viewL / gs) * gs; x < viewR; x += gs) {
      ctx.moveTo(x, Math.max(0, viewT));
      ctx.lineTo(x, Math.min(game.worldH, viewB));
    }
    for (let y = Math.floor(viewT / gs) * gs; y < viewB; y += gs) {
      ctx.moveTo(Math.max(0, viewL), y);
      ctx.lineTo(Math.min(game.worldW, viewR), y);
    }
    ctx.stroke();

    // arena center emblem
    ctx.save();
    ctx.globalAlpha = 0.1;
    ctx.strokeStyle = '#5ad7ff';
    ctx.lineWidth = 4;
    ctx.translate(game.worldW / 2, game.worldH / 2);
    ctx.rotate(t * 0.08);
    ctx.beginPath();
    ctx.arc(0, 0, 300, 0, 7);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(0, 0, 210, 0.4, 3.2);
    ctx.stroke();
    ctx.restore();

    // player light pool
    const lp = ctx.createRadialGradient(game.px, game.py, 10, game.px, game.py, 460);
    lp.addColorStop(0, 'rgba(90,200,255,0.13)');
    lp.addColorStop(1, 'rgba(90,200,255,0)');
    ctx.fillStyle = lp;
    ctx.beginPath();
    ctx.arc(game.px, game.py, 460, 0, 7);
    ctx.fill();

    // spawn markers
    for (const m of game.markers) {
      const k = 1 - m.t / m.max;
      ctx.save();
      ctx.globalAlpha = 0.35 + Math.sin(t * 30) * 0.25;
      ctx.strokeStyle = '#ff3b5c';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(m.x, m.y, 14 + k * 26, 0, 7);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(m.x - 26, m.y);
      ctx.lineTo(m.x + 26, m.y);
      ctx.moveTo(m.x, m.y - 26);
      ctx.lineTo(m.x, m.y + 26);
      ctx.stroke();
      ctx.restore();
    }

    // smoke particles (under entities)
    ctx.save();
    for (const p of game.particles) {
      if (p.kind !== 'smoke') continue;
      const a = clamp(p.life / p.maxLife, 0, 1);
      ctx.globalAlpha = a * 0.45;
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size * (1.6 - a * 0.6), 0, 7);
      ctx.fill();
    }
    ctx.restore();

    // pickups
    for (const p of game.pickups) {
      const bob = Math.sin(p.t * 4) * 4;
      const col = p.type === 'health' ? '#4dff9e' : p.type === 'ammo' ? '#ffd24d' : '#4fd2ff';
      ctx.save();
      ctx.translate(p.x, p.y + bob);
      ctx.globalCompositeOperation = 'lighter';
      const g = ctx.createRadialGradient(0, 0, 1, 0, 0, 30);
      g.addColorStop(0, col);
      g.addColorStop(1, 'transparent');
      ctx.globalAlpha = 0.5;
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(0, 0, 30, 0, 7);
      ctx.fill();
      ctx.globalCompositeOperation = 'source-over';
      ctx.globalAlpha = 1;
      ctx.rotate(p.t * 1.6);
      ctx.fillStyle = col;
      ctx.fillRect(-7, -7, 14, 14);
      ctx.fillStyle = '#06121a';
      if (p.type === 'health') { ctx.fillRect(-4.5, -1.6, 9, 3.2); ctx.fillRect(-1.6, -4.5, 3.2, 9); }
      else if (p.type === 'ammo') { ctx.fillRect(-3.5, -4, 2.5, 8); ctx.fillRect(1, -4, 2.5, 8); }
      else { ctx.beginPath(); ctx.arc(0, 0, 4, 0, 7); ctx.fill(); }
      ctx.restore();
    }

    // obstacles
    for (const o of game.obstacles) {
      if (o.x > viewR || o.x + o.w < viewL || o.y > viewB || o.y + o.h < viewT) continue;
      ctx.fillStyle = 'rgba(0,0,0,0.5)';
      ctx.fillRect(o.x + 6, o.y + 8, o.w, o.h);
      const g = ctx.createLinearGradient(o.x, o.y, o.x, o.y + o.h);
      g.addColorStop(0, '#1b2440');
      g.addColorStop(1, '#0f1426');
      ctx.fillStyle = g;
      ctx.fillRect(o.x, o.y, o.w, o.h);
      ctx.strokeStyle = `hsla(${o.hue},80%,65%,0.45)`;
      ctx.lineWidth = 2;
      ctx.strokeRect(o.x + 1, o.y + 1, o.w - 2, o.h - 2);
      ctx.fillStyle = `hsla(${o.hue},90%,70%,0.5)`;
      ctx.fillRect(o.x + 6, o.y + 6, Math.min(26, o.w - 12), 3);
    }

    // enemies
    for (const e of game.enemies) {
      if (e.x < viewL || e.x > viewR || e.y < viewT || e.y > viewB) continue;
      ctx.save();
      ctx.globalAlpha = 0.35;
      ctx.fillStyle = '#000';
      ctx.beginPath();
      ctx.ellipse(e.x + 4, e.y + 8, e.radius * 0.95, e.radius * 0.5, 0, 0, 7);
      ctx.fill();
      ctx.restore();
      drawEnemyShape(e, t);
    }

    // player
    drawPlayer(ctx, game, t);

    // bullets + sparks (additive)
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    for (const b of game.bullets) {
      const tx = b.x - (b.vx / (Math.hypot(b.vx, b.vy) || 1)) * b.tracer;
      const ty = b.y - (b.vy / (Math.hypot(b.vx, b.vy) || 1)) * b.tracer;
      const grad = ctx.createLinearGradient(tx, ty, b.x, b.y);
      grad.addColorStop(0, 'rgba(255,255,255,0)');
      grad.addColorStop(1, b.glow);
      ctx.strokeStyle = grad;
      ctx.lineWidth = b.size * 1.6;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(tx, ty);
      ctx.lineTo(b.x, b.y);
      ctx.stroke();
      ctx.fillStyle = b.crit ? '#ffffff' : b.color;
      ctx.beginPath();
      ctx.arc(b.x, b.y, b.size * 0.75, 0, 7);
      ctx.fill();
    }
    for (const p of game.particles) {
      const a = clamp(p.life / p.maxLife, 0, 1);
      if (p.kind === 'spark') {
        ctx.globalAlpha = a;
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * a, 0, 7);
        ctx.fill();
      } else if (p.kind === 'ring') {
        ctx.globalAlpha = a * 0.8;
        ctx.strokeStyle = p.color;
        ctx.lineWidth = 4 * a + 1;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * (1.15 - a), 0, 7);
        ctx.stroke();
      } else if (p.kind === 'flash') {
        ctx.globalAlpha = a;
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot);
        const g = ctx.createRadialGradient(0, 0, 1, 0, 0, p.size);
        g.addColorStop(0, '#fff');
        g.addColorStop(0.3, p.color);
        g.addColorStop(1, 'transparent');
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.ellipse(p.size * 0.3, 0, p.size, p.size * 0.5, 0, 0, 7);
        ctx.fill();
        ctx.restore();
      }
    }
    ctx.restore();

    // damage numbers
    ctx.save();
    ctx.textAlign = 'center';
    for (const p of game.particles) {
      if (p.kind !== 'text') continue;
      const a = clamp(p.life / p.maxLife, 0, 1);
      ctx.globalAlpha = a;
      ctx.font = `800 ${p.size}px ui-sans-serif, system-ui, sans-serif`;
      ctx.lineWidth = 3;
      ctx.strokeStyle = 'rgba(0,0,0,0.85)';
      ctx.strokeText(p.text ?? '', p.x, p.y);
      ctx.fillStyle = p.color;
      ctx.fillText(p.text ?? '', p.x, p.y);
    }
    ctx.restore();

    ctx.restore(); // world

    drawOverlay(ctx, game, t);
  };
}

function drawPlayer(ctx: CanvasRenderingContext2D, game: Game, t: number) {
  const { px, py, pangle } = game;
  ctx.save();
  ctx.globalAlpha = 0.4;
  ctx.fillStyle = '#000';
  ctx.beginPath();
  ctx.ellipse(px + 4, py + 9, 16, 8, 0, 0, 7);
  ctx.fill();
  ctx.restore();

  ctx.save();
  ctx.translate(px, py);

  if (game.shield > 0) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.strokeStyle = `rgba(79,210,255,${0.35 + Math.sin(t * 6) * 0.15})`;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(0, 0, 26 + Math.sin(t * 4) * 2, 0, 7);
    ctx.stroke();
    ctx.restore();
  }

  ctx.rotate(pangle);
  const inv = game.invuln > 0 && Math.floor(t * 22) % 2 === 0;

  // legs
  const stride = Math.sin(game.walkT) * 7;
  ctx.fillStyle = '#1d2c46';
  ctx.fillRect(-6, -12 + stride * 0.3, 10, 8);
  ctx.fillRect(-6, 4 - stride * 0.3, 10, 8);

  // body
  const bodyGrad = ctx.createLinearGradient(-14, -14, 14, 14);
  bodyGrad.addColorStop(0, inv ? '#ffffff' : '#dff2ff');
  bodyGrad.addColorStop(1, inv ? '#ffffff' : '#7ea8c9');
  ctx.fillStyle = bodyGrad;
  ctx.beginPath();
  ctx.arc(0, 0, 14, 0, 7);
  ctx.fill();
  ctx.strokeStyle = '#2affea';
  ctx.lineWidth = 2;
  ctx.stroke();

  // visor
  ctx.fillStyle = '#0a1a2a';
  ctx.beginPath();
  ctx.arc(0, 0, 9, 0, 7);
  ctx.fill();
  ctx.fillStyle = '#2affea';
  ctx.fillRect(2, -5, 6, 10);

  // gun
  const rec = -game.recoil;
  const w = WEAPONS[game.weapon];
  ctx.fillStyle = '#141a28';
  ctx.strokeStyle = w.glow;
  ctx.lineWidth = 1.5;
  if (game.weapon === 'shotgun') {
    ctx.fillRect(8 + rec, -4, 26, 8);
    ctx.strokeRect(8 + rec, -4, 26, 8);
  } else if (game.weapon === 'railgun') {
    ctx.fillRect(6 + rec, -3.5, 36, 7);
    ctx.strokeRect(6 + rec, -3.5, 36, 7);
    ctx.fillStyle = w.glow;
    ctx.fillRect(16 + rec, -6, 5, 12);
  } else if (game.weapon === 'launcher') {
    ctx.fillRect(8 + rec, -5, 28, 10);
    ctx.strokeRect(8 + rec, -5, 28, 10);
  } else {
    ctx.fillRect(8 + rec, -3, 30, 6);
    ctx.strokeRect(8 + rec, -3, 30, 6);
  }
  ctx.restore();

  // reload ring
  if (game.reloading) {
    const pct = 1 - game.reloadT / game.reloadDur;
    ctx.save();
    ctx.translate(px, py);
    ctx.strokeStyle = 'rgba(255,255,255,0.25)';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(0, 0, 30, 0, 7);
    ctx.stroke();
    ctx.strokeStyle = '#ffd24d';
    ctx.beginPath();
    ctx.arc(0, 0, 30, -Math.PI / 2, -Math.PI / 2 + pct * Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }
}

function drawOverlay(ctx: CanvasRenderingContext2D, game: Game, t: number) {
  const W = game.W;
  const H = game.H;

  // offscreen enemy indicators
  ctx.save();
  for (const e of game.enemies) {
    const s = game.worldToScreen(e.x, e.y);
    if (s.x > 40 && s.x < W - 40 && s.y > 40 && s.y < H - 40) continue;
    const cx = W / 2;
    const cy = H / 2;
    const a = Math.atan2(s.y - cy, s.x - cx);
    const rx = Math.min(W, H) * 0.42;
    const ix = cx + Math.cos(a) * rx;
    const iy = cy + Math.sin(a) * rx * 0.95;
    ctx.save();
    ctx.translate(ix, iy);
    ctx.rotate(a);
    ctx.globalAlpha = e.kind === 'boss' ? 0.95 : 0.6;
    ctx.fillStyle = e.kind === 'boss' ? '#ff1f5a' : e.elite ? '#ffd45e' : '#ff5c7a';
    ctx.beginPath();
    ctx.moveTo(10, 0);
    ctx.lineTo(-6, 6);
    ctx.lineTo(-6, -6);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }
  ctx.restore();

  // vignette
  const vg = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.35, W / 2, H / 2, Math.max(W, H) * 0.78);
  vg.addColorStop(0, 'rgba(0,0,0,0)');
  vg.addColorStop(1, 'rgba(0,0,0,0.82)');
  ctx.fillStyle = vg;
  ctx.fillRect(0, 0, W, H);

  // low hp pulse
  const hpPct = game.hp / game.stats.maxHp;
  if (hpPct < 0.35 && game.waveState !== 'dead') {
    const a = (0.18 + Math.sin(t * 7) * 0.1) * (1 - hpPct / 0.35);
    const g = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.2, W / 2, H / 2, Math.max(W, H) * 0.7);
    g.addColorStop(0, 'rgba(255,0,40,0)');
    g.addColorStop(1, `rgba(255,0,40,${a})`);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);
  }

  if (game.hurtFlash > 0) {
    ctx.fillStyle = `rgba(255,30,60,${game.hurtFlash * 0.28})`;
    ctx.fillRect(0, 0, W, H);
  }
  if (game.healFlash > 0) {
    ctx.fillStyle = `rgba(60,255,160,${game.healFlash * 0.13})`;
    ctx.fillRect(0, 0, W, H);
  }

  // scanlines
  ctx.save();
  ctx.globalAlpha = 0.045;
  ctx.fillStyle = '#8fd8ff';
  for (let y = 0; y < H; y += 3) ctx.fillRect(0, y, W, 1);
  ctx.restore();

  // crosshair
  const mx = game.mouseX;
  const my = game.mouseY;
  const spread = 8 + game.recoil * 3 + (game.reloading ? 14 : 0);
  ctx.save();
  ctx.strokeStyle = game.reloading ? 'rgba(255,210,77,0.8)' : 'rgba(120,255,235,0.9)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  for (let i = 0; i < 4; i++) {
    const a = (i / 4) * Math.PI * 2 + Math.PI / 4;
    ctx.moveTo(mx + Math.cos(a) * spread, my + Math.sin(a) * spread);
    ctx.lineTo(mx + Math.cos(a) * (spread + 8), my + Math.sin(a) * (spread + 8));
  }
  ctx.stroke();
  ctx.fillStyle = 'rgba(120,255,235,0.9)';
  ctx.fillRect(mx - 1, my - 1, 2, 2);
  ctx.restore();

  // minimap
  const mw = 168;
  const mh = mw * (game.worldH / game.worldW);
  const mxo = W - mw - 22;
  const myo = H - mh - 22;
  ctx.save();
  ctx.globalAlpha = 0.82;
  ctx.fillStyle = 'rgba(6,12,22,0.85)';
  ctx.fillRect(mxo, myo, mw, mh);
  ctx.strokeStyle = 'rgba(90,215,255,0.5)';
  ctx.lineWidth = 1.5;
  ctx.strokeRect(mxo, myo, mw, mh);
  const sx = mw / game.worldW;
  const sy = mh / game.worldH;
  ctx.fillStyle = 'rgba(120,160,220,0.35)';
  for (const o of game.obstacles) ctx.fillRect(mxo + o.x * sx, myo + o.y * sy, o.w * sx, o.h * sy);
  for (const p of game.pickups) {
    ctx.fillStyle = p.type === 'health' ? '#4dff9e' : p.type === 'ammo' ? '#ffd24d' : '#4fd2ff';
    ctx.fillRect(mxo + p.x * sx - 1.5, myo + p.y * sy - 1.5, 3, 3);
  }
  for (const e of game.enemies) {
    ctx.fillStyle = e.kind === 'boss' ? '#ff1f5a' : e.elite ? '#ffd45e' : '#ff5c7a';
    const r = e.kind === 'boss' ? 4 : 2;
    ctx.beginPath();
    ctx.arc(mxo + e.x * sx, myo + e.y * sy, r, 0, 7);
    ctx.fill();
  }
  ctx.fillStyle = '#2affea';
  ctx.beginPath();
  ctx.arc(mxo + game.px * sx, myo + game.py * sy, 3.2, 0, 7);
  ctx.fill();
  ctx.restore();
}
