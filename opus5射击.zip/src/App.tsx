import { useCallback, useEffect, useRef, useState } from 'react';
import { Game, type HudState } from './game/engine';
import { attachRenderer } from './game/render';
import { audio } from './game/audio';
import type { UpgradeDef, WeaponId } from './game/core';
import { Hud } from './components/Hud';
import { GameOverScreen, MainMenu, PauseMenu, UpgradeOverlay } from './components/Screens';

type Screen = 'menu' | 'playing' | 'gameover';

const BEST_KEY = 'obsidian-protocol-best';

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const gameRef = useRef<Game | null>(null);
  const [screen, setScreen] = useState<Screen>('menu');
  const [hud, setHud] = useState<HudState | null>(null);
  const [upgrades, setUpgrades] = useState<UpgradeDef[] | null>(null);
  const [paused, setPaused] = useState(false);
  const [muted, setMuted] = useState(false);
  const [over, setOver] = useState<{ score: number; wave: number; kills: number; time: number } | null>(null);
  const [best, setBest] = useState<{ score: number; wave: number }>({ score: 0, wave: 0 });
  const [isBest, setIsBest] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(BEST_KEY);
      if (raw) setBest(JSON.parse(raw));
    } catch { /* ignore */ }
  }, []);

  // create engine once
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const g = new Game(canvas);
    gameRef.current = g;
    attachRenderer(g);
    g.onHud = (h) => setHud(h);
    g.onUpgrade = (opts) => setUpgrades(opts);
    g.onGameOver = (s) => {
      setOver(s);
      setScreen('gameover');
      let prev = { score: 0, wave: 0 };
      try {
        const raw = localStorage.getItem(BEST_KEY);
        if (raw) prev = JSON.parse(raw);
      } catch { /* ignore */ }
      if (s.score > prev.score) {
        const nb = { score: s.score, wave: s.wave };
        try { localStorage.setItem(BEST_KEY, JSON.stringify(nb)); } catch { /* ignore */ }
        setBest(nb);
        setIsBest(true);
      } else {
        setIsBest(false);
      }
    };

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const w = window.innerWidth;
      const h = window.innerHeight;
      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      g.resize(w, h, dpr);
      g.mouseX = g.mouseX || w / 2;
      g.mouseY = g.mouseY || h / 2;
    };
    resize();
    window.addEventListener('resize', resize);
    return () => {
      window.removeEventListener('resize', resize);
      g.stop();
    };
  }, []);

  // input
  useEffect(() => {
    const g = gameRef.current;
    if (!g) return;

    const down = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (k === ' ') e.preventDefault();
      if (screen !== 'playing') return;
      g.keys.add(k);
      if (k === 'r') g.beginReload();
      if (k === ' ') g.dash();
      if (k === '1') g.switchWeapon('rifle');
      if (k === '2') g.switchWeapon('shotgun');
      if (k === '3') g.switchWeapon('railgun');
      if (k === '4') g.switchWeapon('launcher');
      if (k === 'q') g.cycleWeapon(-1);
      if (k === 'e') g.cycleWeapon(1);
      if (k === 'escape' || k === 'p') {
        setPaused((p) => {
          const np = !p;
          g.paused = np;
          if (np) g.mouseDown = false;
          return np;
        });
      }
      if (k === 'm') {
        setMuted((m) => {
          audio.setMuted(!m);
          return !m;
        });
      }
    };
    const up = (e: KeyboardEvent) => g.keys.delete(e.key.toLowerCase());
    const move = (e: MouseEvent) => {
      g.mouseX = e.clientX;
      g.mouseY = e.clientY;
    };
    const md = (e: MouseEvent) => {
      if (e.button === 0 && screen === 'playing' && !g.paused) g.mouseDown = true;
    };
    const mu = () => { g.mouseDown = false; };
    const wheel = (e: WheelEvent) => {
      if (screen === 'playing') g.cycleWeapon(e.deltaY > 0 ? 1 : -1);
    };
    const blur = () => {
      g.keys.clear();
      g.mouseDown = false;
    };
    const ctxMenu = (e: Event) => e.preventDefault();

    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    window.addEventListener('mousemove', move);
    window.addEventListener('mousedown', md);
    window.addEventListener('mouseup', mu);
    window.addEventListener('wheel', wheel, { passive: true });
    window.addEventListener('blur', blur);
    window.addEventListener('contextmenu', ctxMenu);
    return () => {
      window.removeEventListener('keydown', down);
      window.removeEventListener('keyup', up);
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mousedown', md);
      window.removeEventListener('mouseup', mu);
      window.removeEventListener('wheel', wheel);
      window.removeEventListener('blur', blur);
      window.removeEventListener('contextmenu', ctxMenu);
    };
  }, [screen]);

  const startGame = useCallback(() => {
    const g = gameRef.current;
    if (!g) return;
    audio.init();
    audio.startMusic(1);
    audio.setMuted(muted);
    setUpgrades(null);
    setOver(null);
    setPaused(false);
    g.paused = false;
    g.start();
    setScreen('playing');
  }, [muted]);

  const quitToMenu = useCallback(() => {
    const g = gameRef.current;
    if (!g) return;
    g.stop();
    g.paused = false;
    setPaused(false);
    setUpgrades(null);
    audio.stopMusic();
    setScreen('menu');
  }, []);

  const pickUpgrade = useCallback((id: string) => {
    setUpgrades(null);
    gameRef.current?.chooseUpgrade(id);
  }, []);

  const resume = useCallback(() => {
    const g = gameRef.current;
    if (g) g.paused = false;
    setPaused(false);
  }, []);

  const toggleMute = useCallback(() => {
    setMuted((m) => {
      audio.setMuted(!m);
      return !m;
    });
  }, []);

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-[#04060c]">
      <canvas ref={canvasRef} className="absolute inset-0" />

      {screen === 'playing' && hud && <Hud h={hud} />}
      {screen === 'playing' && upgrades && <UpgradeOverlay options={upgrades} onPick={pickUpgrade} />}
      {screen === 'playing' && paused && (
        <PauseMenu onResume={resume} onQuit={quitToMenu} muted={muted} onToggleMute={toggleMute} />
      )}
      {screen === 'menu' && <MainMenu onStart={startGame} best={best} />}
      {screen === 'gameover' && over && (
        <GameOverScreen stats={over} onRestart={startGame} onMenu={quitToMenu} isBest={isBest} />
      )}

      {screen !== 'menu' && (
        <button
          onClick={toggleMute}
          className="absolute right-6 top-1/2 z-30 font-display text-[10px] tracking-[0.3em] text-cyan-200/40 hover:text-cyan-200"
        >
          {muted ? 'MUTED' : 'SOUND'}
        </button>
      )}
    </div>
  );
}

export type { WeaponId };
