import { useEffect, useState } from 'react';
import type { UpgradeDef } from '../game/core';
import { WEAPONS, WEAPON_ORDER } from '../game/core';
import heroBg from '../assets/hero.jpg';

const RARITY: Record<string, { ring: string; text: string; bg: string; label: string }> = {
  common: { ring: 'border-cyan-400/50', text: 'text-cyan-300', bg: 'from-cyan-500/15', label: '标准' },
  rare: { ring: 'border-violet-400/60', text: 'text-violet-300', bg: 'from-violet-500/20', label: '稀有' },
  epic: { ring: 'border-amber-400/70', text: 'text-amber-300', bg: 'from-amber-500/20', label: '史诗' },
};

export function MainMenu({ onStart, best }: { onStart: () => void; best: { score: number; wave: number } }) {
  const [tab, setTab] = useState<'brief' | 'arsenal' | 'controls'>('brief');
  return (
    <div className="absolute inset-0 overflow-hidden bg-[#04060c]">
      <div
        className="absolute inset-0 bg-cover bg-center opacity-55"
        style={{ backgroundImage: `url(${heroBg})` }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-[#04060c] via-[#04060c]/70 to-[#04060c]/40" />
      <div className="absolute inset-0 bg-grid opacity-40" />
      <div className="pointer-events-none absolute inset-x-0 top-0 h-40 animate-scan bg-gradient-to-b from-cyan-400/10 to-transparent" />

      <div className="relative flex h-full flex-col justify-between p-10 md:p-16">
        <div className="animate-slide-left">
          <div className="mb-3 flex items-center gap-3">
            <span className="h-px w-16 bg-cyan-400/60" />
            <span className="font-display text-[11px] tracking-[0.55em] text-cyan-300/80">CLASSIFIED // OPERATION</span>
          </div>
          <h1 className="animate-flicker font-display text-6xl font-black leading-[0.9] tracking-tight text-white text-glow md:text-8xl">
            黑曜协议
          </h1>
          <h2 className="mt-2 font-display text-2xl font-bold tracking-[0.35em] text-cyan-300/90 md:text-4xl">
            OBSIDIAN PROTOCOL
          </h2>
          <p className="mt-5 max-w-xl text-base leading-relaxed tracking-wide text-slate-300/80 md:text-lg">
            深空殖民站 <span className="text-cyan-300">EX-09</span> 已被未知污染体占领。
            作为唯一幸存的强化步兵，你必须在无尽的敌潮中守住核心区域，
            解锁重型军械，撕碎每一波深渊主宰。
          </p>
        </div>

        <div className="flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
          <div className="w-full max-w-2xl">
            <div className="mb-3 flex gap-1">
              {([
                ['brief', '任务简报'],
                ['arsenal', '军械库'],
                ['controls', '操作'],
              ] as const).map(([k, label]) => (
                <button
                  key={k}
                  onClick={() => setTab(k)}
                  className={`clip-tag px-4 py-1.5 font-display text-[11px] tracking-[0.3em] transition ${
                    tab === k ? 'bg-cyan-400/25 text-white' : 'bg-black/50 text-white/45 hover:text-white/80'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
            <div className="clip-card min-h-[150px] border border-cyan-400/20 bg-black/55 p-5 backdrop-blur-sm">
              {tab === 'brief' && (
                <ul className="space-y-2 text-sm tracking-wide text-slate-300/85">
                  <li>▸ 每 5 波出现一名 <span className="text-rose-400">深渊主宰（BOSS）</span>，拥有多阶段攻击模式。</li>
                  <li>▸ 每波结束后可选择一项 <span className="text-cyan-300">战术强化</span>，构筑你的流派。</li>
                  <li>▸ 连杀可累积 <span className="text-amber-300">COMBO 倍率</span>，受伤即清零。</li>
                  <li>▸ 精英敌人（金色轮廓）拥有双倍血量与分数。</li>
                </ul>
              )}
              {tab === 'arsenal' && (
                <div className="grid grid-cols-2 gap-3">
                  {WEAPON_ORDER.map((id) => {
                    const w = WEAPONS[id];
                    return (
                      <div key={id} className="border-l-2 pl-3" style={{ borderColor: w.glow }}>
                        <div className="font-display text-xs tracking-[0.25em]" style={{ color: w.glow }}>
                          {w.code}
                        </div>
                        <div className="text-sm text-white/85">{w.name}</div>
                        <div className="text-[11px] tracking-wider text-white/40">
                          伤害 {w.damage} · 弹匣 {w.mag} · 第 {w.unlockWave} 波解锁
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
              {tab === 'controls' && (
                <div className="grid grid-cols-2 gap-y-2 text-sm tracking-wide text-slate-300/85">
                  <span><Key>W</Key><Key>A</Key><Key>S</Key><Key>D</Key> 移动</span>
                  <span><Key>鼠标</Key> 瞄准 / <Key>左键</Key> 射击</span>
                  <span><Key>SPACE</Key> 相位闪避（无敌帧）</span>
                  <span><Key>R</Key> 换弹 · <Key>滚轮</Key> 切换武器</span>
                  <span><Key>1</Key><Key>2</Key><Key>3</Key><Key>4</Key> 选择武器</span>
                  <span><Key>ESC</Key> 暂停 · <Key>M</Key> 静音</span>
                </div>
              )}
            </div>
          </div>

          <div className="flex flex-col items-start gap-4 lg:items-end">
            {best.score > 0 && (
              <div className="text-left lg:text-right">
                <div className="font-display text-[10px] tracking-[0.4em] text-cyan-300/60">BEST RECORD</div>
                <div className="font-display text-2xl font-black text-white">
                  {best.score.toLocaleString()} <span className="text-sm text-white/40">/ 第 {best.wave} 波</span>
                </div>
              </div>
            )}
            <button
              onClick={onStart}
              className="clip-card group relative animate-pulse-glow border-2 border-cyan-300/80 bg-cyan-400/10 px-14 py-5 font-display text-2xl font-black tracking-[0.35em] text-white transition hover:bg-cyan-300/25"
            >
              开始作战
              <span className="absolute inset-0 -translate-x-full bg-white/20 transition-transform duration-500 group-hover:translate-x-full" />
            </button>
            <div className="font-display text-[10px] tracking-[0.35em] text-white/30">v1.0 · WEBGL-FREE CANVAS ENGINE</div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Key({ children }: { children: React.ReactNode }) {
  return (
    <kbd className="mx-0.5 inline-block min-w-[24px] border border-white/25 bg-white/5 px-1.5 py-0.5 text-center font-display text-[10px] text-cyan-200">
      {children}
    </kbd>
  );
}

export function UpgradeOverlay({ options, onPick }: { options: UpgradeDef[]; onPick: (id: string) => void }) {
  return (
    <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-black/80 backdrop-blur-md">
      <div className="animate-float-up text-center">
        <div className="font-display text-[11px] tracking-[0.6em] text-cyan-300/70">TACTICAL UPGRADE</div>
        <h2 className="mt-2 font-display text-5xl font-black tracking-widest text-white text-glow">选择强化</h2>
      </div>
      <div className="mt-10 flex flex-wrap justify-center gap-6">
        {options.map((u, i) => {
          const r = RARITY[u.rarity];
          return (
            <button
              key={u.id}
              onClick={() => onPick(u.id)}
              style={{ animationDelay: `${i * 90}ms` }}
              className={`clip-card animate-float-up group w-64 border ${r.ring} bg-gradient-to-b ${r.bg} to-black/70 p-6 text-left transition hover:-translate-y-2 hover:bg-white/10`}
            >
              <div className="flex items-start justify-between">
                <span className={`text-4xl ${r.text}`}>{u.icon}</span>
                <span className={`font-display text-[10px] tracking-[0.3em] ${r.text}`}>{r.label}</span>
              </div>
              <div className="mt-5 font-display text-xl font-bold tracking-wide text-white">{u.name}</div>
              <div className="mt-2 text-sm leading-relaxed tracking-wide text-white/60">{u.desc}</div>
              <div className={`mt-5 font-display text-[10px] tracking-[0.4em] ${r.text} opacity-0 transition group-hover:opacity-100`}>
                ▸ 装载
              </div>
            </button>
          );
        })}
      </div>
      <div className="mt-10 font-display text-[11px] tracking-[0.35em] text-white/30">选择后立即回复 25 点生命</div>
    </div>
  );
}

export function PauseMenu({ onResume, onQuit, muted, onToggleMute }: {
  onResume: () => void; onQuit: () => void; muted: boolean; onToggleMute: () => void;
}) {
  return (
    <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-black/75 backdrop-blur-sm">
      <h2 className="font-display text-6xl font-black tracking-[0.3em] text-white text-glow">已暂停</h2>
      <div className="mt-10 flex flex-col gap-3">
        <MenuBtn onClick={onResume}>继续作战</MenuBtn>
        <MenuBtn onClick={onToggleMute}>{muted ? '开启音效' : '关闭音效'}</MenuBtn>
        <MenuBtn onClick={onQuit} danger>返回主菜单</MenuBtn>
      </div>
    </div>
  );
}

function MenuBtn({ children, onClick, danger }: { children: React.ReactNode; onClick: () => void; danger?: boolean }) {
  return (
    <button
      onClick={onClick}
      className={`clip-tag w-64 border px-8 py-3 font-display text-lg tracking-[0.25em] transition ${
        danger
          ? 'border-rose-400/50 text-rose-300 hover:bg-rose-500/20'
          : 'border-cyan-300/50 text-white hover:bg-cyan-400/20'
      }`}
    >
      {children}
    </button>
  );
}

export function GameOverScreen({ stats, onRestart, onMenu, isBest }: {
  stats: { score: number; wave: number; kills: number; time: number };
  onRestart: () => void;
  onMenu: () => void;
  isBest: boolean;
}) {
  const [shown, setShown] = useState(0);
  useEffect(() => {
    const id = window.setInterval(() => setShown((s) => Math.min(s + 1, 4)), 260);
    return () => window.clearInterval(id);
  }, []);
  const mm = Math.floor(stats.time / 60);
  const ss = Math.floor(stats.time % 60);
  const rows = [
    ['最终得分', stats.score.toLocaleString()],
    ['抵达波次', `第 ${stats.wave} 波`],
    ['击杀总数', `${stats.kills}`],
    ['存活时间', `${mm}:${String(ss).padStart(2, '0')}`],
  ];
  return (
    <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-gradient-to-b from-rose-950/60 via-black/85 to-black/95 backdrop-blur-sm">
      <div className="animate-float-up text-center">
        <div className="font-display text-[11px] tracking-[0.6em] text-rose-400/70">SIGNAL LOST</div>
        <h2 className="mt-2 font-display text-7xl font-black tracking-[0.2em] text-rose-500 text-glow-red">任务失败</h2>
      </div>
      <div className="mt-10 w-[380px] space-y-2">
        {rows.map(([k, v], i) => (
          <div
            key={k}
            className={`flex items-center justify-between border-b border-white/10 pb-2 transition-all duration-300 ${
              shown > i ? 'translate-y-0 opacity-100' : 'translate-y-3 opacity-0'
            }`}
          >
            <span className="font-display text-[11px] tracking-[0.3em] text-white/50">{k}</span>
            <span className="font-display text-2xl font-black tabular-nums text-white">{v}</span>
          </div>
        ))}
      </div>
      {isBest && (
        <div className="mt-5 animate-pulse font-display text-sm tracking-[0.4em] text-amber-300">★ 新纪录 ★</div>
      )}
      <div className="mt-10 flex gap-3">
        <MenuBtn onClick={onRestart}>再次出击</MenuBtn>
        <MenuBtn onClick={onMenu} danger>返回主菜单</MenuBtn>
      </div>
    </div>
  );
}
