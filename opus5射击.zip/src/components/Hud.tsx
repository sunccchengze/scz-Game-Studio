import { WEAPONS, WEAPON_ORDER } from '../game/core';
import type { HudState } from '../game/engine';

const KEYMAP: Record<string, string> = { rifle: '1', shotgun: '2', railgun: '3', launcher: '4' };

export function Hud({ h }: { h: HudState }) {
  const hpPct = Math.max(0, h.hp / h.maxHp);
  const ammoPct = h.mag ? h.ammo / h.mag : 0;
  const low = hpPct < 0.3;

  return (
    <div className="pointer-events-none absolute inset-0 select-none font-body">
      {/* corner frame */}
      <div className="absolute inset-3 border border-cyan-400/10" />
      <div className="absolute left-3 top-3 h-8 w-8 border-l-2 border-t-2 border-cyan-400/50" />
      <div className="absolute right-3 top-3 h-8 w-8 border-r-2 border-t-2 border-cyan-400/50" />
      <div className="absolute bottom-3 left-3 h-8 w-8 border-b-2 border-l-2 border-cyan-400/50" />
      <div className="absolute bottom-3 right-3 h-8 w-8 border-b-2 border-r-2 border-cyan-400/50" />

      {/* top-left: mission status */}
      <div className="absolute left-8 top-7 space-y-2">
        <div className="flex items-baseline gap-3">
          <span className="font-display text-[11px] tracking-[0.4em] text-cyan-300/70">WAVE</span>
          <span className="font-display text-4xl font-black leading-none text-white text-glow">
            {String(h.wave).padStart(2, '0')}
          </span>
          {h.wave % 5 === 0 && h.waveState === 'active' && (
            <span className="clip-tag bg-rose-600/90 px-2 py-0.5 font-display text-[10px] font-bold tracking-widest text-white">
              BOSS
            </span>
          )}
        </div>
        <div className="flex items-center gap-2 text-[11px] tracking-[0.25em] text-cyan-200/60">
          <span className="inline-block h-1.5 w-1.5 animate-pulse rounded-full bg-rose-500" />
          敌对目标 {h.enemiesLeft}
        </div>
      </div>

      {/* top-right: score */}
      <div className="absolute right-8 top-7 text-right">
        <div className="font-display text-[11px] tracking-[0.4em] text-cyan-300/70">SCORE</div>
        <div className="font-display text-3xl font-black tabular-nums text-white text-glow">
          {h.score.toLocaleString()}
        </div>
        {h.combo > 1 && (
          <div className="mt-1">
            <div className="font-display text-lg font-black text-amber-300 text-glow">
              ×{h.combo} COMBO
            </div>
            <div className="ml-auto h-1 w-28 overflow-hidden bg-white/10">
              <div className="h-full bg-amber-400 transition-[width] duration-100" style={{ width: `${h.comboPct * 100}%` }} />
            </div>
          </div>
        )}
        <div className="mt-1 text-[11px] tracking-[0.25em] text-cyan-200/50">击杀 {h.kills}</div>
      </div>

      {/* boss bar */}
      {h.bossMax > 0 && (
        <div className="absolute left-1/2 top-6 w-[min(680px,60vw)] -translate-x-1/2 animate-float-up">
          <div className="mb-1 flex items-center justify-between font-display text-[11px] tracking-[0.35em] text-rose-300">
            <span>{h.bossName}</span>
            <span>{Math.ceil((h.bossHp / h.bossMax) * 100)}%</span>
          </div>
          <div className="h-3 w-full skew-x-[-20deg] border border-rose-500/50 bg-black/60 p-[2px]">
            <div
              className="h-full bg-gradient-to-r from-rose-700 via-rose-500 to-orange-400 transition-[width] duration-150"
              style={{ width: `${(h.bossHp / h.bossMax) * 100}%` }}
            />
          </div>
        </div>
      )}

      {/* center banner */}
      {h.bannerT > 0 && (
        <div
          className="absolute left-1/2 top-[28%] -translate-x-1/2 text-center"
          style={{ opacity: Math.min(1, h.bannerT / 0.6) }}
        >
          <div className="font-display text-5xl font-black tracking-[0.15em] text-white text-glow">{h.banner}</div>
          <div className="mt-2 font-display text-sm tracking-[0.45em] text-cyan-300/80">{h.bannerSub}</div>
        </div>
      )}

      {/* countdown */}
      {h.waveState === 'countdown' && (
        <div className="absolute left-1/2 top-[46%] -translate-x-1/2 text-center">
          <div className="font-display text-8xl font-black text-cyan-300/80 text-glow tabular-nums">
            {Math.ceil(h.countdown)}
          </div>
        </div>
      )}

      {/* bottom-left: vitals */}
      <div className="absolute bottom-8 left-8 w-[330px] space-y-2">
        <div className="flex items-end justify-between">
          <span className="font-display text-[10px] tracking-[0.4em] text-cyan-300/70">VITALS</span>
          <span className={`font-display text-2xl font-black tabular-nums ${low ? 'text-rose-400 text-glow-red animate-pulse' : 'text-white'}`}>
            {h.hp}
            <span className="ml-1 text-sm text-white/40">/{h.maxHp}</span>
          </span>
        </div>
        <div className="relative h-4 skew-x-[-20deg] border border-cyan-400/40 bg-black/70 p-[2px]">
          <div
            className={`h-full transition-[width] duration-150 ${low ? 'bg-gradient-to-r from-rose-700 to-rose-400' : 'bg-gradient-to-r from-emerald-600 via-emerald-400 to-teal-300'}`}
            style={{ width: `${hpPct * 100}%` }}
          />
          <div className="pointer-events-none absolute inset-0 flex">
            {Array.from({ length: 10 }).map((_, i) => (
              <div key={i} className="h-full flex-1 border-r border-black/50 last:border-0" />
            ))}
          </div>
        </div>
        {h.shield > 0 && (
          <div className="h-2 skew-x-[-20deg] border border-sky-400/40 bg-black/60 p-[1px]">
            <div className="h-full bg-gradient-to-r from-sky-500 to-cyan-300" style={{ width: `${(h.shield / 80) * 100}%` }} />
          </div>
        )}
        <div className="flex items-center gap-2">
          <span className="font-display text-[10px] tracking-[0.3em] text-cyan-300/60">DASH</span>
          <div className="h-1.5 flex-1 skew-x-[-20deg] bg-white/10">
            <div
              className={`h-full ${h.dashPct >= 1 ? 'bg-cyan-300' : 'bg-cyan-700'}`}
              style={{ width: `${h.dashPct * 100}%` }}
            />
          </div>
          <span className="font-display text-[10px] tracking-widest text-cyan-200/50">SPACE</span>
        </div>
      </div>

      {/* bottom-center: weapon */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2">
        <div className="flex items-end gap-4">
          <div className="clip-card border border-cyan-400/30 bg-black/60 px-5 py-3 backdrop-blur-sm">
            <div className="font-display text-[10px] tracking-[0.35em] text-cyan-300/70">
              {WEAPONS[h.weapon].code}
            </div>
            <div className="mt-0.5 text-sm tracking-widest text-white/80">{WEAPONS[h.weapon].name}</div>
            <div className="mt-1 flex items-baseline gap-1">
              <span
                className={`font-display text-4xl font-black tabular-nums ${
                  h.reloading ? 'text-amber-300' : ammoPct < 0.25 ? 'text-rose-400' : 'text-white'
                }`}
              >
                {h.reloading ? '——' : String(h.ammo).padStart(2, '0')}
              </span>
              <span className="font-display text-lg text-white/35">/ {h.mag}</span>
            </div>
            <div className="mt-1 h-1 w-44 bg-white/10">
              <div
                className={`h-full ${h.reloading ? 'bg-amber-400' : 'bg-cyan-300'}`}
                style={{ width: `${(h.reloading ? h.reloadPct : ammoPct) * 100}%` }}
              />
            </div>
            {h.reloading && (
              <div className="mt-1 font-display text-[10px] tracking-[0.4em] text-amber-300">RELOADING...</div>
            )}
          </div>

          <div className="flex gap-1.5">
            {WEAPON_ORDER.map((id) => {
              const un = h.unlocked.includes(id);
              const active = h.weapon === id;
              return (
                <div
                  key={id}
                  className={`clip-tag w-16 border px-1.5 py-1 text-center transition-all ${
                    active
                      ? 'border-cyan-300 bg-cyan-400/20 text-white'
                      : un
                        ? 'border-white/15 bg-black/50 text-white/45'
                        : 'border-white/5 bg-black/40 text-white/15'
                  }`}
                >
                  <div className="font-display text-[9px] tracking-widest">{KEYMAP[id]}</div>
                  <div className="font-display text-[9px] leading-tight">{un ? WEAPONS[id].code : 'LOCKED'}</div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* controls hint */}
      <div className="absolute bottom-8 right-[210px] hidden text-right font-display text-[10px] leading-relaxed tracking-[0.2em] text-cyan-200/35 xl:block">
        <div>WASD 移动 · 鼠标瞄准</div>
        <div>左键射击 · R 换弹</div>
        <div>SPACE 闪避 · ESC 暂停</div>
      </div>
    </div>
  );
}
